#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HTTPS_PORT="${HTTPS_PORT:-9443}"
PHP_PORT="${PHP_PORT:-9080}"
PHP_HOST="${PHP_HOST:-127.0.0.1}"
CERT_DIR="$ROOT_DIR/.cert"
CERT_FILE="$CERT_DIR/lan-cert.pem"
KEY_FILE="$CERT_DIR/lan-key.pem"
CERT_CFG_FILE="$CERT_DIR/openssl-lan.cnf"
PHP_LOG="/tmp/ar-management-php.log"
HTTPS_LOG="/tmp/ar-management-https.log"
PHP_UPLOAD_MAX="${PHP_UPLOAD_MAX:-256M}"
PHP_POST_MAX="${PHP_POST_MAX:-256M}"
PHP_MEMORY_LIMIT="${PHP_MEMORY_LIMIT:-512M}"
PHP_MAX_FILE_UPLOADS="${PHP_MAX_FILE_UPLOADS:-64}"

detect_lan_ip() {
  local ip=""
  ip="$(ifconfig en0 2>/dev/null | awk '/inet / {print $2}' | head -n1 || true)"
  if [[ -z "$ip" ]]; then
    ip="$(ifconfig | awk '/inet 192\.168\./ {print $2; exit}' || true)"
  fi
  if [[ -z "$ip" ]]; then
    ip="$(ifconfig | awk '/inet 10\./ {print $2; exit}' || true)"
  fi
  if [[ -z "$ip" ]]; then
    ip="127.0.0.1"
  fi
  echo "$ip"
}

LAN_IP="${LAN_IP:-$(detect_lan_ip)}"

cleanup() {
  if [[ -n "${PHP_PID:-}" ]] && kill -0 "$PHP_PID" 2>/dev/null; then
    kill "$PHP_PID" 2>/dev/null || true
  fi
  if [[ -n "${HTTPS_PID:-}" ]] && kill -0 "$HTTPS_PID" 2>/dev/null; then
    kill "$HTTPS_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

cd "$ROOT_DIR"

mkdir -p "$CERT_DIR"

if [[ ! -f "$CERT_FILE" || ! -f "$KEY_FILE" ]]; then
  cat >"$CERT_CFG_FILE" <<EOF
[req]
default_bits = 2048
prompt = no
default_md = sha256
x509_extensions = v3_req
distinguished_name = dn

[dn]
CN = ${LAN_IP}

[v3_req]
subjectAltName = @alt_names

[alt_names]
IP.1 = ${LAN_IP}
IP.2 = 127.0.0.1
DNS.1 = localhost
EOF
  echo "Generating LAN certificate for ${LAN_IP} ..."
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout "$KEY_FILE" \
    -out "$CERT_FILE" \
    -config "$CERT_CFG_FILE" >/dev/null 2>&1
fi

echo "Starting PHP server on http://${PHP_HOST}:${PHP_PORT} ..."
php \
  -d upload_max_filesize="$PHP_UPLOAD_MAX" \
  -d post_max_size="$PHP_POST_MAX" \
  -d memory_limit="$PHP_MEMORY_LIMIT" \
  -d max_file_uploads="$PHP_MAX_FILE_UPLOADS" \
  -S "${PHP_HOST}:${PHP_PORT}" \
  -t "$ROOT_DIR" >"$PHP_LOG" 2>&1 &
PHP_PID=$!

sleep 1
if ! kill -0 "$PHP_PID" 2>/dev/null; then
  echo "PHP server failed. Log:"
  cat "$PHP_LOG"
  exit 1
fi

echo "Starting HTTPS reverse proxy on https://0.0.0.0:${HTTPS_PORT} ..."
LISTEN_HOST="0.0.0.0" \
LISTEN_PORT="$HTTPS_PORT" \
TARGET_HOST="$PHP_HOST" \
TARGET_PORT="$PHP_PORT" \
CERT_PATH="$CERT_FILE" \
KEY_PATH="$KEY_FILE" \
node "$ROOT_DIR/https-php-proxy.js" >"$HTTPS_LOG" 2>&1 &
HTTPS_PID=$!

sleep 1
if ! kill -0 "$HTTPS_PID" 2>/dev/null; then
  echo "HTTPS proxy failed. Log:"
  cat "$HTTPS_LOG"
  exit 1
fi

URL="https://${LAN_IP}:${HTTPS_PORT}"

if [[ "$LAN_IP" != "127.0.0.1" ]]; then
  echo
  echo "Open platform on your phone:"
  echo "${URL}/"
  echo
  echo "Management panel login:"
  echo "${URL}/platform/index.php"
  if [[ -d "$ROOT_DIR/instances" ]]; then
    FIRST_INSTANCE="$(find "$ROOT_DIR/instances" -mindepth 1 -maxdepth 1 -type d | head -n1 | xargs -I{} basename "{}" 2>/dev/null || true)"
    if [[ -n "${FIRST_INSTANCE:-}" ]]; then
      echo
      echo "Example instance AR app:"
      echo "${URL}/instances/${FIRST_INSTANCE}/"
      echo "Example instance admin:"
      echo "${URL}/instances/${FIRST_INSTANCE}/admin-panel/index.php"
    fi
  fi
  echo
else
  echo
  echo "Open locally:"
  echo "${URL}/"
  echo
fi

echo "If browser warns about certificate, continue once and trust it."
echo "Keep this terminal open. Press Ctrl+C to stop."

for _ in {1..3}; do
  if curl -ksf "${URL}/" >/dev/null 2>&1 && curl -ksf "${URL}/platform/index.php" >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

wait "$HTTPS_PID"
