#!/usr/bin/env node
/* eslint-disable no-console */
const fs = require("fs");
const http = require("http");
const https = require("https");
const net = require("net");

const listenHost = process.env.LISTEN_HOST || "0.0.0.0";
const listenPort = Number(process.env.LISTEN_PORT || 9443);
const targetHost = process.env.TARGET_HOST || "127.0.0.1";
const targetPort = Number(process.env.TARGET_PORT || 9080);
const certPath = process.env.CERT_PATH;
const keyPath = process.env.KEY_PATH;

if (!certPath || !keyPath) {
  console.error("Missing CERT_PATH or KEY_PATH");
  process.exit(1);
}

const cert = fs.readFileSync(certPath);
const key = fs.readFileSync(keyPath);

const requestHandler = (req, res) => {
  const headers = { ...req.headers, host: `${targetHost}:${targetPort}` };
  const upstream = http.request(
    {
      hostname: targetHost,
      port: targetPort,
      method: req.method,
      path: req.url,
      headers,
    },
    (upstreamRes) => {
      res.writeHead(upstreamRes.statusCode || 502, upstreamRes.headers);
      upstreamRes.pipe(res);
    },
  );

  upstream.on("error", (err) => {
    res.writeHead(502, { "content-type": "text/plain; charset=utf-8" });
    res.end(`HTTPS proxy error: ${err.message}`);
  });

  req.pipe(upstream);
};

const httpsServer = https.createServer({ cert, key }, requestHandler);

httpsServer.on("clientError", (err, socket) => {
  socket.end("HTTP/1.1 400 Bad Request\r\n\r\n");
  console.error("Client error:", err.message);
});

const httpRedirectServer = http.createServer((req, res) => {
  const hostHeader = String(req.headers.host || "").trim();
  const hostOnly = hostHeader.replace(/:\d+$/, "") || listenHost || "localhost";
  const location = `https://${hostOnly}:${listenPort}${req.url || "/"}`;
  res.writeHead(308, { location });
  res.end();
});

httpRedirectServer.on("clientError", (err, socket) => {
  socket.end("HTTP/1.1 400 Bad Request\r\n\r\n");
  console.error("HTTP redirect client error:", err.message);
});

const server = net.createServer((socket) => {
  socket.once("data", (buffer) => {
    const firstByte = buffer[0];
    const isTlsHandshake = firstByte === 22;
    const targetServer = isTlsHandshake ? httpsServer : httpRedirectServer;

    socket.pause();
    targetServer.emit("connection", socket);
    socket.unshift(buffer);
    socket.resume();
  });
});

server.on("error", (err) => {
  console.error("Proxy listener error:", err.message);
});

server.listen(listenPort, listenHost, () => {
  console.log(
    `Dual HTTP/HTTPS proxy listening on ${listenHost}:${listenPort} -> http://${targetHost}:${targetPort}`,
  );
});
