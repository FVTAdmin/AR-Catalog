<?php
declare(strict_types=1);

header('Location: ./platform/index.php');
exit;

