<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';

platform_bootstrap();
$lang = platform_panel_language();
platform_logout_user();
platform_redirect(platform_panel_url(['plang' => $lang]));
