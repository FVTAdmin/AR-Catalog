<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
require __DIR__ . '/ui.php';

platform_bootstrap();
$lang = platform_panel_language();
$user = platform_require_login(null);
$role = strtolower((string)($user['role'] ?? ''));
if ($role === 'god') {
    platform_redirect(platform_management_url(['plang' => $lang]));
}

$instanceSlug = (string)($user['instance_slug'] ?? '');
$instanceName = (string)($user['instance_name'] ?? '');
platform_render_page_start(platform_t('dashboard_client'));
platform_render_topbar($user);
?>

<div class="card">
  <h2><?php echo platform_h(platform_t('dashboard_client')); ?></h2>
  <p class="muted"><?php echo platform_h(platform_t('welcome', ['name' => (string)($user['username'] ?? '')])); ?></p>
</div>

<?php if ($instanceSlug === ''): ?>
  <div class="card">
    <h2><?php echo platform_h(platform_t('your_instance')); ?></h2>
    <p class="muted"><?php echo platform_h(platform_t('not_assigned')); ?></p>
  </div>
<?php else: ?>
  <?php
    $appHref = platform_instance_app_url($instanceSlug, ['v' => (string)time()]);
    $adminHref = platform_instance_admin_url($instanceSlug);
  ?>
  <div class="card">
    <h2><?php echo platform_h(platform_t('your_instance')); ?></h2>
    <div class="grid-2">
      <div class="field">
        <label><?php echo platform_h(platform_t('instance')); ?></label>
        <div><strong><?php echo platform_h($instanceName !== '' ? $instanceName : $instanceSlug); ?></strong></div>
      </div>
    </div>
    <div style="margin-top:12px;" class="actions">
      <a class="btn secondary" href="<?php echo platform_h($appHref); ?>" target="_blank" rel="noopener noreferrer"><?php echo platform_h(platform_t('open_app')); ?></a>
      <a class="btn secondary" href="<?php echo platform_h($adminHref); ?>" target="_blank" rel="noopener noreferrer"><?php echo platform_h(platform_t('open_admin')); ?></a>
    </div>
  </div>
<?php endif; ?>

<?php platform_render_page_end(); ?>
