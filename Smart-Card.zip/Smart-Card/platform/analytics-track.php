<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$raw = file_get_contents('php://input');
$payload = [];
if (is_string($raw) && trim($raw) !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $payload = $decoded;
    }
}
if (count($payload) === 0) {
    $payload = $_POST;
}

$instanceSlug = trim((string)($payload['instance'] ?? ''));
if ($instanceSlug === '') {
    $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
    $instanceSlug = $referer !== '' ? (string)(platform_detect_instance_slug_from_pathname($referer) ?? '') : '';
}

$eventName = strtolower(trim((string)($payload['event'] ?? '')));
$sessionKey = trim((string)($payload['session'] ?? ''));
$meta = $payload['meta'] ?? [];
if (!is_array($meta)) {
    $meta = [];
}
$userAgent = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');

try {
    $ok = platform_record_analytics_event($instanceSlug, $eventName, $sessionKey, $meta, $userAgent);
    echo json_encode(['ok' => $ok]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false]);
}
