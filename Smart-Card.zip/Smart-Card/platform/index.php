<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
require __DIR__ . '/ui.php';

platform_bootstrap();
$lang = platform_panel_language();
$errors = [];
$flash = platform_consume_flash();
$nextFromGet = platform_sanitize_next_path((string)($_GET['next'] ?? ''));
$nextFromPost = platform_sanitize_next_path((string)($_POST['next'] ?? ''));
$nextPath = $nextFromPost !== '' ? $nextFromPost : $nextFromGet;

$currentUser = platform_current_user();
if ($currentUser) {
    if ($nextPath !== '') {
        platform_redirect($nextPath);
    }
    $role = strtolower((string)($currentUser['role'] ?? ''));
    platform_redirect(platform_role_dashboard_url($role, ['plang' => $lang]));
}

$hasGod = platform_has_god_user();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if (!platform_csrf_check($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid security token. Refresh the page and retry.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'setup_god') {
            if ($hasGod) {
                $errors[] = 'Initial setup is already completed.';
            } else {
                $username = trim((string)($_POST['username'] ?? ''));
                $password = (string)($_POST['password'] ?? '');
                $confirmPassword = (string)($_POST['confirm_password'] ?? '');

                if ($password !== $confirmPassword) {
                    $errors[] = platform_t('error_password_mismatch');
                } else {
                    [$ok, $message] = platform_create_user($username, $password, 'god', null);
                    if (!$ok) {
                        $errors[] = $message;
                    } else {
                        $user = platform_find_user_by_username($username);
                        if ($user) {
                            platform_login_user($user);
                            platform_set_flash('ok', platform_t('success_god_created'));
                            platform_redirect(platform_management_url(['plang' => $lang]));
                        }
                        $errors[] = 'Account was created but login failed.';
                    }
                }
            }
        } elseif ($action === 'login') {
            $username = trim((string)($_POST['username'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $user = platform_authenticate($username, $password);
            if (!$user) {
                $errors[] = platform_t('error_invalid_credentials');
            } else {
                platform_login_user($user);
                if ($nextPath !== '') {
                    platform_redirect($nextPath);
                }
                $role = strtolower((string)($user['role'] ?? ''));
                platform_redirect(platform_role_dashboard_url($role, ['plang' => $lang]));
            }
        }
    }
}

platform_render_page_start(platform_t('login_title'));
platform_render_topbar(null);
platform_render_flash($flash);
foreach ($errors as $error) {
    platform_render_flash(['type' => 'err', 'message' => $error]);
}
?>

<?php if (!$hasGod): ?>
  <div class="card">
    <h2><?php echo platform_h(platform_t('setup_title')); ?></h2>
    <p class="muted"><?php echo platform_h(platform_t('setup_subtitle')); ?></p>
    <form method="post" action="">
      <input type="hidden" name="action" value="setup_god" />
      <input type="hidden" name="csrf_token" value="<?php echo platform_h(platform_csrf_token()); ?>" />
      <input type="hidden" name="panel_lang" value="<?php echo platform_h($lang); ?>" />
      <div class="grid-2">
        <div class="field">
          <label><?php echo platform_h(platform_t('username')); ?></label>
          <input type="text" name="username" required autocomplete="username" />
        </div>
        <div class="field">
          <label><?php echo platform_h(platform_t('password')); ?></label>
          <input type="password" name="password" required autocomplete="new-password" />
        </div>
        <div class="field">
          <label><?php echo platform_h(platform_t('confirm_password')); ?></label>
          <input type="password" name="confirm_password" required autocomplete="new-password" />
        </div>
      </div>
      <div style="margin-top:10px;">
        <button type="submit"><?php echo platform_h(platform_t('create_god_account')); ?></button>
      </div>
    </form>
  </div>
<?php else: ?>
  <div class="card">
    <h2><?php echo platform_h(platform_t('login_title')); ?></h2>
    <p class="muted"><?php echo platform_h(platform_t('login_subtitle')); ?></p>
    <form method="post" action="">
      <input type="hidden" name="action" value="login" />
      <input type="hidden" name="csrf_token" value="<?php echo platform_h(platform_csrf_token()); ?>" />
      <input type="hidden" name="panel_lang" value="<?php echo platform_h($lang); ?>" />
      <input type="hidden" name="next" value="<?php echo platform_h($nextPath); ?>" />
      <div class="grid-2">
        <div class="field">
          <label><?php echo platform_h(platform_t('username')); ?></label>
          <input type="text" name="username" required autocomplete="username" />
        </div>
        <div class="field">
          <label><?php echo platform_h(platform_t('password')); ?></label>
          <input type="password" name="password" required autocomplete="current-password" />
        </div>
      </div>
      <div style="margin-top:10px;">
        <button type="submit"><?php echo platform_h(platform_t('sign_in')); ?></button>
      </div>
    </form>
  </div>
<?php endif; ?>

<?php platform_render_page_end(); ?>
