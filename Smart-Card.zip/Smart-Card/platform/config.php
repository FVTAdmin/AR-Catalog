<?php
declare(strict_types=1);

return [
    'app_name' => 'AR Management Center',
    'session_name' => 'arcp_session',
    'default_panel_language' => 'en',
    'instance_root_dirname' => 'instances',
    // Instance template source (copied into each new instance root).
    'instance_template_dir' => 'platform/instance-template',
    'db' => [
        // mysql | sqlite
        // For cPanel shared host set this to "mysql" and fill mysql values below.
        'driver' => 'sqlite',
        'allow_sqlite_fallback' => true,
        'sqlite_path' => __DIR__ . '/../data/platform.sqlite',
        'mysql' => [
            'host' => '127.0.0.1',
            'port' => 3306,
            'database' => '',
            'username' => '',
            'password' => '',
            'charset' => 'utf8mb4',
        ],
    ],
    'template_paths' => [
        '.htaccess',
        'index.html',
        'ar-cache-version.json',
        'ar-card-config.json',
        'ar-card-config.js',
        'ar-card-languages.json',
        'ar-card-languages.js',
        'assets',
        'admin-panel',
    ],
];
