<?php
declare(strict_types=1);
require_once __DIR__ . '/lib.php';

function platform_page_url(string $path, array $query = []): string
{
    return platform_url($path, $query);
}

function platform_render_page_start(string $title): void
{
    $lang = platform_panel_language();
    $dir = platform_is_rtl($lang) ? 'rtl' : 'ltr';
    $appName = platform_t('app_name');
    ?>
<!DOCTYPE html>
<html lang="<?php echo platform_h($lang); ?>" dir="<?php echo platform_h($dir); ?>">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo platform_h($title . ' - ' . $appName); ?></title>
  <style>
    :root {
      --bg: #0b1118;
      --panel: #111a24;
      --line: #233445;
      --text: #ebf2fa;
      --muted: #9cb0c4;
      --accent: #39d3ce;
      --ok: #2ecc71;
      --err: #ff7f7f;
    }
    * {
      box-sizing: border-box;
      -webkit-tap-highlight-color: transparent;
    }
    a,
    button,
    input,
    select,
    textarea {
      -webkit-tap-highlight-color: transparent;
      outline: none;
    }
    body {
      margin: 0;
      background: radial-gradient(circle at top, #102033 0%, var(--bg) 46%);
      color: var(--text);
      font-family: Tahoma, Arial, sans-serif;
      min-height: 100vh;
    }
    .wrap {
      max-width: 1080px;
      margin: 0 auto;
      padding: 18px 14px 40px;
    }
    .topbar {
      display: flex;
      gap: 10px;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }
    .brand {
      font-size: 20px;
      font-weight: 700;
      margin: 0;
    }
    .controls {
      display: flex;
      gap: 8px;
      align-items: center;
      flex-wrap: wrap;
    }
    .lang-form {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      border: 1px solid var(--line);
      border-radius: 999px;
      padding: 6px 10px;
      background: rgba(10, 18, 26, 0.88);
    }
    .lang-form label {
      color: var(--muted);
      font-size: 12px;
    }
    select, input[type="text"], input[type="password"] {
      width: 100%;
      border: 1px solid #2f455a;
      border-radius: 8px;
      background: #0c1520;
      color: #eff6ff;
      font-size: 13px;
      padding: 8px 10px;
      min-height: 36px;
    }
    button, .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 9px;
      border: 1px solid rgba(57, 211, 206, 0.62);
      background: rgba(57, 211, 206, 0.16);
      color: #d9fffd;
      font-size: 13px;
      font-weight: 700;
      min-height: 36px;
      padding: 0 12px;
      text-decoration: none;
      cursor: pointer;
    }
    button:disabled,
    .btn:disabled {
      opacity: 0.55;
      cursor: not-allowed;
    }
    .btn.secondary {
      border-color: #385066;
      background: #14202c;
      color: #d8e7f6;
    }
    .btn.danger {
      border-color: rgba(255, 111, 111, 0.62);
      background: rgba(255, 107, 107, 0.16);
      color: #ffdede;
    }
    .card {
      border: 1px solid var(--line);
      border-radius: 12px;
      background: var(--panel);
      padding: 14px;
      margin-bottom: 12px;
    }
    .card h2 {
      margin: 0 0 10px;
      font-size: 18px;
    }
    .muted {
      color: var(--muted);
      font-size: 13px;
      margin-top: 0;
      margin-bottom: 10px;
    }
    .grid-2 {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 10px;
    }
    .field {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .field label {
      font-size: 12px;
      color: #d7e5f4;
    }
    .flash {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 10px 12px;
      margin-bottom: 12px;
      font-size: 13px;
      background: #0f1722;
    }
    .flash.ok {
      border-color: rgba(46, 204, 113, 0.52);
      color: #d2ffe5;
    }
    .flash.err {
      border-color: rgba(255, 127, 127, 0.52);
      color: #ffd8d8;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }
    .table-wrap {
      width: 100%;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
    }
    th, td {
      border-bottom: 1px solid #243647;
      padding: 9px 7px;
      text-align: start;
      vertical-align: top;
    }
    th {
      color: #d7e6f6;
      font-weight: 700;
      font-size: 12px;
    }
    .actions {
      display: flex;
      gap: 6px;
      flex-wrap: wrap;
    }
    .quota-grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 8px;
      margin-top: 8px;
    }
    .quota-item {
      border: 1px solid #2c3e50;
      border-radius: 9px;
      padding: 8px;
      background: #0f1822;
    }
    .quota-item .k {
      color: var(--muted);
      font-size: 11px;
    }
    .quota-item .v {
      font-size: 20px;
      font-weight: 700;
      line-height: 1.2;
      margin-top: 2px;
    }
    .quota-meter {
      margin-top: 9px;
      height: 8px;
      border-radius: 999px;
      border: 1px solid #2a4054;
      background: #0d151f;
      overflow: hidden;
    }
    .quota-meter > span {
      display: block;
      height: 100%;
      background: linear-gradient(90deg, #39d3ce 0%, #6fd8ff 100%);
      border-radius: inherit;
      min-width: 2px;
    }
    code {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      font-size: 12px;
    }
    @media (max-width: 860px) {
      .grid-2 {
        grid-template-columns: 1fr;
      }
      .quota-grid {
        grid-template-columns: 1fr;
      }
      .actions {
        flex-direction: column;
      }
      .actions .btn,
      .actions form,
      .actions form button {
        width: 100%;
      }
      table {
        min-width: 760px;
      }
    }
  </style>
</head>
<body>
  <div class="wrap">
<?php
}

function platform_render_topbar(?array $user = null): void
{
    $lang = platform_panel_language();
    $supported = platform_supported_panel_languages();
    ?>
    <div class="topbar">
      <h1 class="brand"><?php echo platform_h(platform_t('app_name')); ?></h1>
      <div class="controls">
        <form class="lang-form" method="get" action="">
          <label for="panel-lang"><?php echo platform_h(platform_t('panel_language')); ?></label>
          <select id="panel-lang" name="plang" onchange="this.form.submit()">
            <?php foreach ($supported as $code => $meta): ?>
              <option value="<?php echo platform_h($code); ?>" <?php echo $code === $lang ? 'selected' : ''; ?>>
                <?php echo platform_h($meta['native']); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </form>
        <?php if ($user): ?>
          <a class="btn secondary" href="<?php echo platform_h(platform_page_url('platform/logout.php', ['plang' => $lang])); ?>"><?php echo platform_h(platform_t('logout')); ?></a>
        <?php endif; ?>
      </div>
    </div>
<?php
}

function platform_render_flash(?array $flash): void
{
    if (!$flash || !isset($flash['message'])) {
        return;
    }
    $type = ($flash['type'] ?? 'err') === 'ok' ? 'ok' : 'err';
    ?>
    <div class="flash <?php echo platform_h($type); ?>"><?php echo platform_h((string)$flash['message']); ?></div>
<?php
}

function platform_render_page_end(): void
{
    ?>
  </div>
</body>
</html>
<?php
}
