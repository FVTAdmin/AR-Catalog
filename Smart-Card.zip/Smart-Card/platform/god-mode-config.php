<?php
declare(strict_types=1);

return [
    // Hard limit for how many AR app/panel instances can exist in God Mode.
    // Change this number based on your plan.
    'max_instances_per_god_user' => 5,
];

