<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
require __DIR__ . '/ui.php';

platform_bootstrap();
$lang = platform_panel_language();
$user = platform_require_login('god');
$errors = [];

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if (!platform_csrf_check($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid security token. Refresh the page and retry.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'create_instance') {
            $password = (string)($_POST['password'] ?? '');
            $confirmPassword = (string)($_POST['confirm_password'] ?? '');
            if ($password !== $confirmPassword) {
                $errors[] = platform_t('error_password_mismatch');
            } else {
                [$ok, $message, $instance] = platform_create_instance([
                    'display_name' => (string)($_POST['display_name'] ?? ''),
                    'slug' => (string)($_POST['slug'] ?? ''),
                    'username' => (string)($_POST['username'] ?? ''),
                    'password' => $password,
                    'default_language' => (string)($_POST['default_language'] ?? 'fa'),
                ]);
                if ($ok && is_array($instance)) {
                    $details = $message
                        . ' '
                        . 'Slug: ' . ($instance['slug'] ?? '')
                        . ' | Username: ' . ($instance['username'] ?? '');
                    platform_set_flash('ok', $details);
                    platform_redirect(platform_management_url(['plang' => $lang]));
                }
                $errors[] = $message;
            }
        } elseif ($action === 'delete_instance') {
            $instanceId = (int)($_POST['instance_id'] ?? 0);
            if ($instanceId <= 0) {
                $errors[] = platform_t('error_instance_not_found');
            } else {
                [$okDelete, $deleteMessage] = platform_delete_instance($instanceId);
                if ($okDelete) {
                    platform_set_flash('ok', $deleteMessage);
                    platform_redirect(platform_management_url(['plang' => $lang]));
                }
                $errors[] = $deleteMessage;
            }
        }
    }
}

$flash = platform_consume_flash();
$instances = platform_list_instances();
$instanceLimit = platform_max_instances_per_god_user();
$instanceCount = count($instances);
$instanceRemaining = max(0, $instanceLimit - $instanceCount);
$instanceUsagePercent = $instanceLimit > 0 ? (int)min(100, round(($instanceCount / $instanceLimit) * 100)) : 0;
$quotaReached = $instanceRemaining <= 0;
platform_render_page_start(platform_t('dashboard_god'));
platform_render_topbar($user);
platform_render_flash($flash);
foreach ($errors as $error) {
    platform_render_flash(['type' => 'err', 'message' => $error]);
}
?>

<div class="card">
  <h2><?php echo platform_h(platform_t('dashboard_god')); ?></h2>
  <p class="muted"><?php echo platform_h(platform_t('welcome', ['name' => (string)($user['username'] ?? 'admin')])); ?></p>
</div>

<div class="card">
  <h2><?php echo platform_h(platform_t('instance_quota_title')); ?></h2>
  <p class="muted"><?php echo platform_h(platform_t('instance_quota_help')); ?></p>
  <div class="quota-grid">
    <div class="quota-item">
      <div class="k"><?php echo platform_h(platform_t('instance_count_used')); ?></div>
      <div class="v"><?php echo platform_h((string)$instanceCount); ?></div>
    </div>
    <div class="quota-item">
      <div class="k"><?php echo platform_h(platform_t('instance_count_limit')); ?></div>
      <div class="v"><?php echo platform_h((string)$instanceLimit); ?></div>
    </div>
    <div class="quota-item">
      <div class="k"><?php echo platform_h(platform_t('instance_count_remaining')); ?></div>
      <div class="v"><?php echo platform_h((string)$instanceRemaining); ?></div>
    </div>
  </div>
  <div class="quota-meter">
    <span style="width: <?php echo platform_h((string)$instanceUsagePercent); ?>%;"></span>
  </div>
</div>

<div class="card">
  <h2><?php echo platform_h(platform_t('create_instance')); ?></h2>
  <?php if ($quotaReached): ?>
    <div class="flash err"><?php echo platform_h(platform_t('error_instance_quota_reached', ['limit' => (string)$instanceLimit])); ?></div>
  <?php endif; ?>
  <form method="post" action="">
    <input type="hidden" name="action" value="create_instance" />
    <input type="hidden" name="csrf_token" value="<?php echo platform_h(platform_csrf_token()); ?>" />
    <input type="hidden" name="panel_lang" value="<?php echo platform_h($lang); ?>" />
    <div class="grid-2">
      <div class="field">
        <label><?php echo platform_h(platform_t('instance_name')); ?></label>
        <input type="text" name="display_name" required />
      </div>
      <div class="field">
        <label><?php echo platform_h(platform_t('instance_slug')); ?></label>
        <input type="text" name="slug" />
        <div class="muted"><?php echo platform_h(platform_t('instance_slug_help')); ?></div>
      </div>
      <div class="field">
        <label><?php echo platform_h(platform_t('instance_username')); ?></label>
        <input type="text" name="username" required />
      </div>
      <div class="field">
        <label><?php echo platform_h(platform_t('instance_password')); ?></label>
        <input type="password" name="password" required />
      </div>
      <div class="field">
        <label><?php echo platform_h(platform_t('confirm_password')); ?></label>
        <input type="password" name="confirm_password" required />
      </div>
      <div class="field">
        <label><?php echo platform_h(platform_t('instance_default_lang')); ?></label>
        <select name="default_language">
          <?php foreach (platform_supported_panel_languages() as $code => $meta): ?>
            <option value="<?php echo platform_h($code); ?>" <?php echo $code === 'fa' ? 'selected' : ''; ?>>
              <?php echo platform_h($meta['native']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div style="margin-top:10px;">
      <button type="submit" <?php echo $quotaReached ? 'disabled' : ''; ?>><?php echo platform_h(platform_t('create_instance_btn')); ?></button>
    </div>
  </form>
</div>

<div class="card">
  <h2><?php echo platform_h(platform_t('instances_list')); ?></h2>
  <?php if (count($instances) === 0): ?>
    <div class="muted"><?php echo platform_h(platform_t('no_instances')); ?></div>
  <?php else: ?>
    <div class="table-wrap">
    <table>
      <thead>
      <tr>
        <th><?php echo platform_h(platform_t('instance')); ?></th>
        <th><?php echo platform_h(platform_t('owner')); ?></th>
        <th><?php echo platform_h(platform_t('created_at')); ?></th>
        <th><?php echo platform_h(platform_t('actions')); ?></th>
      </tr>
      </thead>
      <tbody>
      <?php foreach ($instances as $row): ?>
        <?php
          $slug = (string)($row['slug'] ?? '');
          $appHref = platform_instance_app_url($slug, ['v' => (string)time()]);
          $adminHref = platform_instance_admin_url($slug);
        ?>
        <tr>
          <td>
            <strong><?php echo platform_h((string)($row['display_name'] ?? '')); ?></strong><br />
          </td>
          <td><?php echo platform_h((string)($row['owner_username'] ?? '')); ?></td>
          <td><?php echo platform_h((string)($row['created_at'] ?? '')); ?></td>
          <td>
            <div class="actions">
              <a class="btn secondary" href="<?php echo platform_h($appHref); ?>" target="_blank" rel="noopener noreferrer"><?php echo platform_h(platform_t('open_app')); ?></a>
              <a class="btn secondary" href="<?php echo platform_h($adminHref); ?>" target="_blank" rel="noopener noreferrer"><?php echo platform_h(platform_t('open_admin')); ?></a>
              <form method="post" action="" data-delete-instance data-confirm="<?php echo platform_h(platform_t('delete_instance_confirm')); ?>" style="margin:0;">
                <input type="hidden" name="action" value="delete_instance" />
                <input type="hidden" name="csrf_token" value="<?php echo platform_h(platform_csrf_token()); ?>" />
                <input type="hidden" name="panel_lang" value="<?php echo platform_h($lang); ?>" />
                <input type="hidden" name="instance_id" value="<?php echo platform_h((string)($row['id'] ?? '0')); ?>" />
                <button type="submit" class="btn danger"><?php echo platform_h(platform_t('delete_instance_btn')); ?></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  <?php endif; ?>
</div>

<script>
  (function () {
    const forms = document.querySelectorAll("form[data-delete-instance]");
    forms.forEach(function (form) {
      form.addEventListener("submit", function (event) {
        const msg = form.getAttribute("data-confirm") || "Delete instance?";
        if (!window.confirm(msg)) {
          event.preventDefault();
        }
      });
    });
  })();
</script>

<?php platform_render_page_end(); ?>
