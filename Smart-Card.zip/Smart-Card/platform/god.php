<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';

platform_bootstrap();
$query = $_GET;
if (!isset($query['plang']) || !is_string($query['plang']) || trim($query['plang']) === '') {
    $query['plang'] = platform_panel_language();
}
platform_redirect(platform_management_url($query));
