<?php
declare(strict_types=1);
require_once __DIR__ . '/lib.php';

function platform_require_admin_panel_access(string $adminDir): void
{
    platform_bootstrap();

    // Backward compatibility: if no accounts are configured yet, keep panel open.
    if (!platform_has_any_user()) {
        return;
    }

    $user = platform_current_user();
    if (!$user) {
        $next = (string)($_SERVER['REQUEST_URI'] ?? '');
        platform_redirect(platform_login_url_with_next($next));
    }

    $role = strtolower((string)($user['role'] ?? ''));
    if ($role === 'god') {
        return;
    }

    $instanceSlug = platform_detect_instance_slug_from_admin_dir($adminDir);
    $userSlug = (string)($user['instance_slug'] ?? '');

    if ($instanceSlug === null || $instanceSlug === '' || $userSlug === '' || $userSlug !== $instanceSlug) {
        http_response_code(403);
        echo platform_h(platform_t('error_permission'));
        exit;
    }
}
