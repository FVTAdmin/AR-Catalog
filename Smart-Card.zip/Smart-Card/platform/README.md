# AR Control Center (God Mode)

Entry URL:

- `/platform/index.php`

This module adds:

- Secure login with username/password (`god` and `client` roles)
- God Mode dashboard for creating tenant instances
- Per-instance user credentials
- Automatic instance folder creation under `instances/<unique-slug>/`
- Instance delete from God dashboard (DB + files)
- Template clone of AR app + AR admin panel for each instance
- Access guard on `admin-panel/` so each client only manages their own instance
- Panel UI language switch (EN/FA/AR/ZH)
- Local analytics endpoint (no external API): `platform/analytics-track.php`

## Local default storage

By default it uses SQLite:

- DB file: `data/platform.sqlite`

## cPanel MySQL mode

Edit `platform/config.php`:

- Set `db.driver` to `mysql`
- Fill `db.mysql.host`
- Fill `db.mysql.port`
- Fill `db.mysql.database`
- Fill `db.mysql.username`
- Fill `db.mysql.password`

No manual SQL import is required; tables are auto-created.

## First-time setup

1. Open `/platform/index.php`
2. If no God account exists, setup form appears
3. Create first God account
4. Login and create instances

## Instance links

For each instance:

- AR app: `/instances/<slug>/`
- AR admin panel: `/instances/<slug>/admin-panel/index.php`

## Local analytics

AR app sends local events to:

- `/platform/analytics-track.php`

Tracked events:

- app open
- target found
- video play / unmute
- action button click
- language toggle
- fullscreen click

The instance admin panel shows 14-day KPIs + trend chart from local DB data.

## Security behavior

- If no users exist yet, old direct `admin-panel` access remains open for bootstrap compatibility.
- Once users exist, `admin-panel` requires login through `/platform/index.php`.
- `god` can access all panels.
- `client` can access only their own instance panel.
