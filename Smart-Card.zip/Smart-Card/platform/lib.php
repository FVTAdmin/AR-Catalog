<?php
declare(strict_types=1);

function platform_root_path(): string
{
    $root = realpath(__DIR__ . '/..');
    return $root !== false ? $root : dirname(__DIR__);
}

function platform_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function platform_load_config(): array
{
    static $config = null;
    if (is_array($config)) {
        return $config;
    }

    $defaults = [
        'app_name' => 'AR Management Center',
        'session_name' => 'arcp_session',
        'default_panel_language' => 'en',
        'instance_root_dirname' => 'instances',
        'db' => [
            'driver' => 'sqlite',
            'allow_sqlite_fallback' => true,
            'sqlite_path' => __DIR__ . '/../data/platform.sqlite',
            'mysql' => [
                'host' => '127.0.0.1',
                'port' => 3306,
                'database' => '',
                'username' => '',
                'password' => '',
                'charset' => 'utf8mb4',
            ],
        ],
        'template_paths' => [
            '.htaccess',
            'index.html',
            'ar-cache-version.json',
            'ar-card-config.json',
            'ar-card-config.js',
            'ar-card-languages.json',
            'ar-card-languages.js',
            'assets',
            'admin-panel',
        ],
    ];

    $config = $defaults;
    $configPath = __DIR__ . '/config.php';
    if (is_file($configPath)) {
        $loaded = require $configPath;
        if (is_array($loaded)) {
            $config = array_replace_recursive($defaults, $loaded);
        }
    }

    return $config;
}

function platform_god_mode_config_path(): string
{
    return __DIR__ . '/god-mode-config.php';
}

function platform_default_god_mode_config(): array
{
    return [
        'max_instances_per_god_user' => 5,
    ];
}

function platform_load_god_mode_config(): array
{
    static $config = null;
    if (is_array($config)) {
        return $config;
    }

    $config = platform_default_god_mode_config();
    $path = platform_god_mode_config_path();
    if (is_file($path)) {
        $loaded = require $path;
        if (is_array($loaded)) {
            $config = array_replace($config, $loaded);
        }
    }

    $limit = (int)($config['max_instances_per_god_user'] ?? 5);
    $config['max_instances_per_god_user'] = max(1, min(100000, $limit));
    return $config;
}

function platform_max_instances_per_god_user(): int
{
    $config = platform_load_god_mode_config();
    return (int)($config['max_instances_per_god_user'] ?? 5);
}

function platform_supported_panel_languages(): array
{
    return [
        'en' => ['name' => 'English', 'native' => 'English', 'dir' => 'ltr'],
        'fa' => ['name' => 'Persian', 'native' => 'فارسی', 'dir' => 'rtl'],
        'ar' => ['name' => 'Arabic', 'native' => 'العربية', 'dir' => 'rtl'],
        'zh' => ['name' => 'Chinese', 'native' => '中文', 'dir' => 'ltr'],
    ];
}

function platform_panel_messages(): array
{
    return [
        'en' => [
            'app_name' => 'AR Management Center',
            'panel_language' => 'Panel Language',
            'login_title' => 'Sign in',
            'login_subtitle' => 'Use your account to access the central management panel or your workspace.',
            'setup_title' => 'First-time Setup',
            'setup_subtitle' => 'Create the first central management account.',
            'username' => 'Username',
            'password' => 'Password',
            'confirm_password' => 'Confirm Password',
            'sign_in' => 'Sign in',
            'create_god_account' => 'Create Management Account',
            'logout' => 'Logout',
            'dashboard_god' => 'Central Management Panel',
            'dashboard_client' => 'Workspace Panel',
            'welcome' => 'Welcome, {name}',
            'create_instance' => 'Create Workspace',
            'instance_name' => 'Workspace Name',
            'instance_slug' => 'Workspace Unique ID',
            'instance_slug_help' => 'Leave empty to generate it from the workspace name.',
            'instance_username' => 'Workspace Login Username',
            'instance_password' => 'Workspace Login Password',
            'instance_default_lang' => 'Default App Language',
            'create_instance_btn' => 'Create Workspace',
            'instances_list' => 'Workspaces',
            'instance_quota_title' => 'Plan Capacity',
            'instance_quota_help' => 'The workspace limit is defined in the platform configuration.',
            'instance_count_used' => 'Used',
            'instance_count_limit' => 'Limit',
            'instance_count_remaining' => 'Remaining',
            'no_instances' => 'No workspace has been created yet.',
            'instance' => 'Workspace',
            'path' => 'Path',
            'owner' => 'Owner',
            'created_at' => 'Created',
            'actions' => 'Actions',
            'open_app' => 'Open Experience',
            'open_admin' => 'Open Content Panel',
            'open_workspace' => 'Open Workspace',
            'your_instance' => 'Your Workspace',
            'not_assigned' => 'No workspace is assigned to this account.',
            'error_invalid_credentials' => 'Invalid username or password.',
            'error_password_mismatch' => 'Password and confirm password do not match.',
            'error_invalid_username' => 'Username must contain 3-64 characters: letters, numbers, dot, dash, underscore.',
            'error_short_password' => 'Password must be at least 8 characters.',
            'error_permission' => 'You do not have permission to access this page.',
            'error_slug_exists' => 'Workspace unique ID is already in use.',
            'error_username_exists' => 'Username is already in use.',
            'error_instance_quota_reached' => 'Workspace limit reached ({limit}). Delete a workspace or increase the allowed limit in the platform configuration.',
            'success_god_created' => 'Management account created successfully.',
            'success_instance_created' => 'Workspace created successfully.',
            'success_instance_deleted' => 'Workspace deleted successfully.',
            'delete_instance_btn' => 'Delete Workspace',
            'delete_instance_confirm' => 'Delete this workspace and all its files? This cannot be undone.',
            'error_instance_not_found' => 'Workspace not found.',
            'error_instance_folder_delete_failed' => 'Could not delete the workspace folder from disk.',
            'back_login' => 'Back to Login',
            'go_dashboard' => 'Go to Dashboard',
        ],
        'fa' => [
            'app_name' => 'مرکز مدیریت AR',
            'panel_language' => 'زبان پنل',
            'login_title' => 'ورود',
            'login_subtitle' => 'با حساب خود وارد پنل مدیریت مرکزی یا فضای کاری اختصاصی شوید.',
            'setup_title' => 'راه‌اندازی اولیه',
            'setup_subtitle' => 'اولین حساب مدیریت مرکزی را بسازید.',
            'username' => 'نام کاربری',
            'password' => 'رمز عبور',
            'confirm_password' => 'تکرار رمز عبور',
            'sign_in' => 'ورود',
            'create_god_account' => 'ساخت حساب مدیریت',
            'logout' => 'خروج',
            'dashboard_god' => 'پنل مدیریت مرکزی',
            'dashboard_client' => 'داشبورد فضای کاری',
            'welcome' => 'خوش آمدید، {name}',
            'create_instance' => 'ساخت فضای کاری',
            'instance_name' => 'نام فضای کاری',
            'instance_slug' => 'شناسه یکتای فضای کاری',
            'instance_slug_help' => 'اگر خالی بگذارید از نام فضای کاری ساخته می‌شود.',
            'instance_username' => 'نام کاربری ورود فضای کاری',
            'instance_password' => 'رمز عبور ورود فضای کاری',
            'instance_default_lang' => 'زبان پیش‌فرض اپ',
            'create_instance_btn' => 'ساخت فضای کاری',
            'instances_list' => 'فضاهای کاری',
            'instance_quota_title' => 'ظرفیت پلن',
            'instance_quota_help' => 'سقف تعداد فضاهای کاری در تنظیمات پلتفرم تعیین می‌شود.',
            'instance_count_used' => 'استفاده شده',
            'instance_count_limit' => 'سقف',
            'instance_count_remaining' => 'باقی‌مانده',
            'no_instances' => 'هنوز فضای کاری‌ای ساخته نشده است.',
            'instance' => 'فضای کاری',
            'path' => 'مسیر',
            'owner' => 'مالک',
            'created_at' => 'تاریخ ساخت',
            'actions' => 'عملیات',
            'open_app' => 'باز کردن تجربه',
            'open_admin' => 'باز کردن پنل محتوا',
            'open_workspace' => 'باز کردن فضای کاری',
            'your_instance' => 'فضای کاری شما',
            'not_assigned' => 'هیچ فضای کاری‌ای به این حساب متصل نیست.',
            'error_invalid_credentials' => 'نام کاربری یا رمز عبور اشتباه است.',
            'error_password_mismatch' => 'رمز عبور و تکرار آن یکسان نیستند.',
            'error_invalid_username' => 'نام کاربری باید ۳ تا ۶۴ کاراکتر شامل حروف، عدد، نقطه، خط فاصله یا آندرلاین باشد.',
            'error_short_password' => 'رمز عبور باید حداقل ۸ کاراکتر باشد.',
            'error_permission' => 'شما دسترسی لازم برای این صفحه را ندارید.',
            'error_slug_exists' => 'شناسه یکتای فضای کاری قبلا استفاده شده است.',
            'error_username_exists' => 'این نام کاربری قبلا استفاده شده است.',
            'error_instance_quota_reached' => 'سقف تعداد فضاهای کاری ({limit}) پر شده است. یک فضای کاری را حذف کنید یا سقف مجاز را در تنظیمات پلتفرم افزایش دهید.',
            'success_god_created' => 'حساب مدیریت با موفقیت ساخته شد.',
            'success_instance_created' => 'فضای کاری با موفقیت ساخته شد.',
            'success_instance_deleted' => 'فضای کاری با موفقیت حذف شد.',
            'delete_instance_btn' => 'حذف فضای کاری',
            'delete_instance_confirm' => 'این فضای کاری و همه فایل‌های آن حذف شود؟ این عمل قابل بازگشت نیست.',
            'error_instance_not_found' => 'فضای کاری پیدا نشد.',
            'error_instance_folder_delete_failed' => 'پوشه فضای کاری از روی دیسک حذف نشد.',
            'back_login' => 'بازگشت به ورود',
            'go_dashboard' => 'رفتن به داشبورد',
        ],
        'ar' => [
            'app_name' => 'مركز إدارة AR',
            'panel_language' => 'لغة اللوحة',
            'login_title' => 'تسجيل الدخول',
            'login_subtitle' => 'استخدم حسابك للوصول إلى لوحة الإدارة المركزية أو مساحة العمل الخاصة بك.',
            'setup_title' => 'الإعداد الأول',
            'setup_subtitle' => 'أنشئ أول حساب للإدارة المركزية.',
            'username' => 'اسم المستخدم',
            'password' => 'كلمة المرور',
            'confirm_password' => 'تأكيد كلمة المرور',
            'sign_in' => 'دخول',
            'create_god_account' => 'إنشاء حساب الإدارة',
            'logout' => 'تسجيل الخروج',
            'dashboard_god' => 'لوحة الإدارة المركزية',
            'dashboard_client' => 'لوحة مساحة العمل',
            'welcome' => 'مرحبًا، {name}',
            'create_instance' => 'إنشاء مساحة عمل',
            'instance_name' => 'اسم مساحة العمل',
            'instance_slug' => 'المعرّف الفريد لمساحة العمل',
            'instance_slug_help' => 'اتركه فارغًا ليتم إنشاؤه من اسم مساحة العمل.',
            'instance_username' => 'اسم مستخدم مساحة العمل',
            'instance_password' => 'كلمة مرور مساحة العمل',
            'instance_default_lang' => 'اللغة الافتراضية للتطبيق',
            'create_instance_btn' => 'إنشاء مساحة العمل',
            'instances_list' => 'مساحات العمل',
            'instance_quota_title' => 'سعة الخطة',
            'instance_quota_help' => 'يتم تحديد حد مساحات العمل في إعدادات المنصة.',
            'instance_count_used' => 'المستخدم',
            'instance_count_limit' => 'الحد',
            'instance_count_remaining' => 'المتبقي',
            'no_instances' => 'لا توجد مساحة عمل حتى الآن.',
            'instance' => 'مساحة العمل',
            'path' => 'المسار',
            'owner' => 'المالك',
            'created_at' => 'تاريخ الإنشاء',
            'actions' => 'الإجراءات',
            'open_app' => 'فتح التجربة',
            'open_admin' => 'فتح لوحة المحتوى',
            'open_workspace' => 'فتح مساحة العمل',
            'your_instance' => 'مساحة العمل الخاصة بك',
            'not_assigned' => 'لا توجد مساحة عمل مرتبطة بهذا الحساب.',
            'error_invalid_credentials' => 'اسم المستخدم أو كلمة المرور غير صحيحة.',
            'error_password_mismatch' => 'كلمة المرور وتأكيدها غير متطابقين.',
            'error_invalid_username' => 'اسم المستخدم يجب أن يكون 3-64 حرفًا (حروف/أرقام/.-_).',
            'error_short_password' => 'كلمة المرور يجب أن تكون 8 أحرف على الأقل.',
            'error_permission' => 'ليست لديك صلاحية الوصول إلى هذه الصفحة.',
            'error_slug_exists' => 'المعرّف الفريد لمساحة العمل مستخدم بالفعل.',
            'error_username_exists' => 'اسم المستخدم مستخدم بالفعل.',
            'error_instance_quota_reached' => 'تم الوصول إلى حد مساحات العمل ({limit}). احذف مساحة عمل أو زد الحد المسموح به في إعدادات المنصة.',
            'success_god_created' => 'تم إنشاء حساب الإدارة بنجاح.',
            'success_instance_created' => 'تم إنشاء مساحة العمل بنجاح.',
            'success_instance_deleted' => 'تم حذف مساحة العمل بنجاح.',
            'delete_instance_btn' => 'حذف مساحة العمل',
            'delete_instance_confirm' => 'هل تريد حذف مساحة العمل هذه وكل ملفاتها؟ لا يمكن التراجع عن ذلك.',
            'error_instance_not_found' => 'مساحة العمل غير موجودة.',
            'error_instance_folder_delete_failed' => 'تعذر حذف مجلد مساحة العمل من الخادم.',
            'back_login' => 'العودة لتسجيل الدخول',
            'go_dashboard' => 'الذهاب للوحة',
        ],
        'zh' => [
            'app_name' => 'AR 管理中心',
            'panel_language' => '面板语言',
            'login_title' => '登录',
            'login_subtitle' => '使用你的账户进入中央管理面板或你的专属工作区。',
            'setup_title' => '首次初始化',
            'setup_subtitle' => '创建第一个中央管理账户。',
            'username' => '用户名',
            'password' => '密码',
            'confirm_password' => '确认密码',
            'sign_in' => '登录',
            'create_god_account' => '创建管理账户',
            'logout' => '退出',
            'dashboard_god' => '中央管理面板',
            'dashboard_client' => '工作区面板',
            'welcome' => '欢迎，{name}',
            'create_instance' => '创建工作区',
            'instance_name' => '工作区名称',
            'instance_slug' => '工作区唯一标识',
            'instance_slug_help' => '留空则根据工作区名称自动生成。',
            'instance_username' => '工作区登录用户名',
            'instance_password' => '工作区登录密码',
            'instance_default_lang' => '应用默认语言',
            'create_instance_btn' => '创建工作区',
            'instances_list' => '工作区',
            'instance_quota_title' => '配额容量',
            'instance_quota_help' => '工作区数量上限由平台配置定义。',
            'instance_count_used' => '已使用',
            'instance_count_limit' => '上限',
            'instance_count_remaining' => '剩余',
            'no_instances' => '还没有创建工作区。',
            'instance' => '工作区',
            'path' => '路径',
            'owner' => '拥有者',
            'created_at' => '创建时间',
            'actions' => '操作',
            'open_app' => '打开体验页',
            'open_admin' => '打开内容面板',
            'open_workspace' => '打开工作区',
            'your_instance' => '你的工作区',
            'not_assigned' => '该账号未绑定工作区。',
            'error_invalid_credentials' => '用户名或密码错误。',
            'error_password_mismatch' => '两次输入的密码不一致。',
            'error_invalid_username' => '用户名需 3-64 字符，可用字母/数字/.-_。',
            'error_short_password' => '密码至少 8 位。',
            'error_permission' => '你没有权限访问此页面。',
            'error_slug_exists' => '工作区唯一标识已存在。',
            'error_username_exists' => '用户名已存在。',
            'error_instance_quota_reached' => '已达到工作区上限（{limit}）。请删除一个工作区或在平台配置中提高允许上限。',
            'success_god_created' => '管理账户创建成功。',
            'success_instance_created' => '工作区创建成功。',
            'success_instance_deleted' => '工作区删除成功。',
            'delete_instance_btn' => '删除工作区',
            'delete_instance_confirm' => '确认删除该工作区及其全部文件？此操作不可撤销。',
            'error_instance_not_found' => '未找到工作区。',
            'error_instance_folder_delete_failed' => '无法从磁盘删除工作区目录。',
            'back_login' => '返回登录',
            'go_dashboard' => '进入面板',
        ],
    ];
}

function platform_normalize_panel_language(string $lang): string
{
    $lang = strtolower(trim($lang));
    $supported = platform_supported_panel_languages();
    return isset($supported[$lang]) ? $lang : 'en';
}

function platform_panel_language(): string
{
    platform_start_session();
    $config = platform_load_config();
    $fallback = platform_normalize_panel_language((string)($config['default_panel_language'] ?? 'en'));

    $candidate = '';
    if (isset($_GET['plang']) && is_string($_GET['plang'])) {
        $candidate = $_GET['plang'];
    } elseif (isset($_POST['panel_lang']) && is_string($_POST['panel_lang'])) {
        $candidate = $_POST['panel_lang'];
    } elseif (isset($_SESSION['platform_panel_lang']) && is_string($_SESSION['platform_panel_lang'])) {
        $candidate = $_SESSION['platform_panel_lang'];
    }

    $lang = $candidate !== '' ? platform_normalize_panel_language($candidate) : $fallback;
    $_SESSION['platform_panel_lang'] = $lang;
    return $lang;
}

function platform_is_rtl(?string $lang = null): bool
{
    $code = $lang ? platform_normalize_panel_language($lang) : platform_panel_language();
    $meta = platform_supported_panel_languages()[$code] ?? null;
    return ($meta['dir'] ?? 'ltr') === 'rtl';
}

function platform_t(string $key, array $vars = [], ?string $lang = null): string
{
    $locale = $lang ? platform_normalize_panel_language($lang) : platform_panel_language();
    $messages = platform_panel_messages();
    $raw = $messages[$locale][$key] ?? $messages['en'][$key] ?? $key;
    foreach ($vars as $k => $v) {
        $raw = str_replace('{' . $k . '}', (string)$v, $raw);
    }
    return $raw;
}

function platform_start_session(): void
{
    $config = platform_load_config();
    $name = trim((string)($config['session_name'] ?? 'arcp_session'));

    if (session_status() === PHP_SESSION_ACTIVE) {
        // If another session name is already active (e.g. PHPSESSID), switch to platform session.
        if ($name !== '' && session_name() !== $name) {
            session_write_close();
            session_name($name);
            session_start();
        }
        return;
    }

    if ($name !== '') {
        session_name($name);
    }
    session_start();
}

function platform_bootstrap(): void
{
    platform_start_session();
    platform_panel_language();
}

function platform_is_valid_username(string $username): bool
{
    return (bool)preg_match('/^[A-Za-z0-9._-]{3,64}$/', $username);
}

function platform_is_valid_password(string $password): bool
{
    return strlen($password) >= 8;
}

function platform_db(): PDO
{
    static $pdo = null;
    static $schemaReady = false;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $config = platform_load_config();
    $db = $config['db'] ?? [];
    $driver = strtolower(trim((string)($db['driver'] ?? 'sqlite')));
    $allowFallback = (bool)($db['allow_sqlite_fallback'] ?? true);

    $lastException = null;
    if ($driver === 'mysql') {
        try {
            $mysql = $db['mysql'] ?? [];
            $host = (string)($mysql['host'] ?? '127.0.0.1');
            $port = (int)($mysql['port'] ?? 3306);
            $database = trim((string)($mysql['database'] ?? ''));
            $username = trim((string)($mysql['username'] ?? ''));
            $password = (string)($mysql['password'] ?? '');
            $charset = trim((string)($mysql['charset'] ?? 'utf8mb4'));

            if ($database === '' || $username === '') {
                throw new RuntimeException('MySQL credentials are incomplete.');
            }

            $dsn = "mysql:host={$host};port={$port};dbname={$database};charset={$charset}";
            $pdo = new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);

            if (!$schemaReady) {
                platform_ensure_schema($pdo, 'mysql');
                $schemaReady = true;
            }
            return $pdo;
        } catch (Throwable $e) {
            $lastException = $e;
            if (!$allowFallback) {
                throw new RuntimeException('MySQL connection failed: ' . $e->getMessage(), 0, $e);
            }
        }
    }

    try {
        $sqlitePath = (string)($db['sqlite_path'] ?? (__DIR__ . '/../data/platform.sqlite'));
        $sqliteDir = dirname($sqlitePath);
        if (!is_dir($sqliteDir) && !mkdir($sqliteDir, 0775, true) && !is_dir($sqliteDir)) {
            throw new RuntimeException('Cannot create SQLite directory: ' . $sqliteDir);
        }
        $pdo = new PDO('sqlite:' . $sqlitePath, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $pdo->exec('PRAGMA foreign_keys = ON');
        if (!$schemaReady) {
            platform_ensure_schema($pdo, 'sqlite');
            $schemaReady = true;
        }
        return $pdo;
    } catch (Throwable $e) {
        if ($lastException) {
            throw new RuntimeException(
                'Database connection failed. MySQL error: ' . $lastException->getMessage() . ' | SQLite error: ' . $e->getMessage()
            );
        }
        throw new RuntimeException('Database connection failed: ' . $e->getMessage(), 0, $e);
    }
}

function platform_ensure_schema(PDO $pdo, string $driver): void
{
    if ($driver === 'mysql') {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS ar_instances (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                slug VARCHAR(120) NOT NULL,
                display_name VARCHAR(190) NOT NULL,
                folder_path VARCHAR(255) NOT NULL,
                default_language VARCHAR(16) NOT NULL DEFAULT 'fa',
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_ar_instances_slug (slug)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );

        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS ar_users (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                username VARCHAR(120) NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                role VARCHAR(16) NOT NULL,
                instance_id INT UNSIGNED NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_ar_users_username (username),
                KEY idx_ar_users_role (role),
                KEY idx_ar_users_instance (instance_id),
                CONSTRAINT fk_ar_users_instance
                  FOREIGN KEY (instance_id) REFERENCES ar_instances(id)
                  ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );

        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS ar_instance_events (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                instance_slug VARCHAR(120) NOT NULL,
                event_name VARCHAR(64) NOT NULL,
                session_key VARCHAR(128) NULL,
                user_agent VARCHAR(255) NULL,
                meta_json TEXT NULL,
                event_ts TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_ar_instance_events_slug_ts (instance_slug, event_ts),
                KEY idx_ar_instance_events_name (event_name),
                KEY idx_ar_instance_events_session (session_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        return;
    }

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ar_instances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slug TEXT NOT NULL UNIQUE,
            display_name TEXT NOT NULL,
            folder_path TEXT NOT NULL,
            default_language TEXT NOT NULL DEFAULT 'fa',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ar_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL,
            instance_id INTEGER NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(instance_id) REFERENCES ar_instances(id) ON DELETE SET NULL
        )"
    );
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS ar_instance_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            instance_slug TEXT NOT NULL,
            event_name TEXT NOT NULL,
            session_key TEXT NULL,
            user_agent TEXT NULL,
            meta_json TEXT NULL,
            event_ts TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )"
    );
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ar_users_role ON ar_users(role)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ar_users_instance ON ar_users(instance_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ar_instance_events_slug_ts ON ar_instance_events(instance_slug, event_ts)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ar_instance_events_name ON ar_instance_events(event_name)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_ar_instance_events_session ON ar_instance_events(session_key)");
}

function platform_has_any_user(): bool
{
    $pdo = platform_db();
    $count = (int)$pdo->query("SELECT COUNT(*) FROM ar_users")->fetchColumn();
    return $count > 0;
}

function platform_has_god_user(): bool
{
    $pdo = platform_db();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM ar_users WHERE role = 'god' AND is_active = 1");
    $stmt->execute();
    return ((int)$stmt->fetchColumn()) > 0;
}

function platform_find_user_by_username(string $username): ?array
{
    $pdo = platform_db();
    $stmt = $pdo->prepare(
        "SELECT
            u.*,
            i.slug AS instance_slug,
            i.display_name AS instance_name,
            i.folder_path AS instance_folder_path
         FROM ar_users u
         LEFT JOIN ar_instances i ON i.id = u.instance_id
         WHERE u.username = :username
         LIMIT 1"
    );
    $stmt->execute([':username' => $username]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

function platform_find_user_by_id(int $id): ?array
{
    $pdo = platform_db();
    $stmt = $pdo->prepare(
        "SELECT
            u.*,
            i.slug AS instance_slug,
            i.display_name AS instance_name,
            i.folder_path AS instance_folder_path
         FROM ar_users u
         LEFT JOIN ar_instances i ON i.id = u.instance_id
         WHERE u.id = :id
         LIMIT 1"
    );
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

function platform_create_user(string $username, string $password, string $role, ?int $instanceId = null): array
{
    if (!platform_is_valid_username($username)) {
        return [false, platform_t('error_invalid_username')];
    }
    if (!platform_is_valid_password($password)) {
        return [false, platform_t('error_short_password')];
    }
    $role = strtolower(trim($role));
    if (!in_array($role, ['god', 'client'], true)) {
        return [false, 'Invalid role.'];
    }

    if (platform_find_user_by_username($username)) {
        return [false, platform_t('error_username_exists')];
    }

    $pdo = platform_db();
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare(
        "INSERT INTO ar_users (username, password_hash, role, instance_id, is_active)
         VALUES (:username, :password_hash, :role, :instance_id, 1)"
    );
    $stmt->execute([
        ':username' => $username,
        ':password_hash' => $hash,
        ':role' => $role,
        ':instance_id' => $instanceId,
    ]);
    return [true, 'ok'];
}

function platform_authenticate(string $username, string $password): ?array
{
    $user = platform_find_user_by_username($username);
    if (!$user) {
        return null;
    }
    $isActive = (int)($user['is_active'] ?? 0) === 1;
    if (!$isActive) {
        return null;
    }
    $hash = (string)($user['password_hash'] ?? '');
    if ($hash === '' || !password_verify($password, $hash)) {
        return null;
    }
    return $user;
}

function platform_login_user(array $user): void
{
    platform_start_session();
    session_regenerate_id(true);
    $_SESSION['platform_auth'] = [
        'user_id' => (int)($user['id'] ?? 0),
    ];
}

function platform_logout_user(): void
{
    platform_start_session();
    unset($_SESSION['platform_auth']);
    session_regenerate_id(true);
}

function platform_current_user(): ?array
{
    platform_start_session();
    $auth = $_SESSION['platform_auth'] ?? null;
    if (!is_array($auth)) {
        return null;
    }
    $id = (int)($auth['user_id'] ?? 0);
    if ($id <= 0) {
        return null;
    }
    $user = platform_find_user_by_id($id);
    if (!$user) {
        return null;
    }
    if ((int)($user['is_active'] ?? 0) !== 1) {
        return null;
    }
    return $user;
}

function platform_request_pathname(): string
{
    $scriptName = (string)($_SERVER['SCRIPT_NAME'] ?? '');
    if ($scriptName !== '') {
        return (string)(parse_url($scriptName, PHP_URL_PATH) ?? $scriptName);
    }

    $requestUri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    return (string)(parse_url($requestUri, PHP_URL_PATH) ?? '/');
}

function platform_project_prefix_from_uri(): string
{
    $path = platform_request_pathname();
    $instanceRoot = trim((string)(platform_load_config()['instance_root_dirname'] ?? 'instances'), '/');
    $markers = ['/platform/'];
    if ($instanceRoot !== '') {
        $markers[] = '/' . $instanceRoot . '/';
    }
    foreach ($markers as $marker) {
        $pos = strpos($path, $marker);
        if ($pos !== false) {
            $prefix = substr($path, 0, $pos);
            return rtrim($prefix, '/');
        }
    }
    return '';
}

function platform_url(string $path, array $query = []): string
{
    $prefix = platform_project_prefix_from_uri();
    $normalizedPath = '/' . ltrim($path, '/');
    $url = ($prefix === '' ? '' : $prefix) . $normalizedPath;
    if (!empty($query)) {
        $url .= '?' . http_build_query($query);
    }
    return $url;
}

function platform_panel_url(array $query = []): string
{
    return platform_url('platform/index.php', $query);
}

function platform_management_url(array $query = []): string
{
    return platform_url('platform/management.php', $query);
}

function platform_workspace_url(array $query = []): string
{
    return platform_url('platform/workspace.php', $query);
}

function platform_role_dashboard_url(string $role, array $query = []): string
{
    return strtolower(trim($role)) === 'god'
        ? platform_management_url($query)
        : platform_workspace_url($query);
}

function platform_instance_app_url(string $slug, array $query = []): string
{
    $instanceRoot = trim((string)(platform_load_config()['instance_root_dirname'] ?? 'instances'), '/');
    if ($instanceRoot === '') {
        $instanceRoot = 'instances';
    }
    return platform_url($instanceRoot . '/' . rawurlencode(trim($slug)) . '/', $query);
}

function platform_instance_admin_url(string $slug, array $query = []): string
{
    $instanceRoot = trim((string)(platform_load_config()['instance_root_dirname'] ?? 'instances'), '/');
    if ($instanceRoot === '') {
        $instanceRoot = 'instances';
    }
    return platform_url($instanceRoot . '/' . rawurlencode(trim($slug)) . '/admin-panel/index.php', $query);
}

function platform_login_url_with_next(string $next = ''): string
{
    $query = ['plang' => platform_panel_language()];
    $cleanNext = platform_sanitize_next_path($next);
    if ($cleanNext !== '') {
        $query['next'] = $cleanNext;
    }
    return platform_panel_url($query);
}

function platform_redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function platform_require_login(?string $requiredRole = null): array
{
    $user = platform_current_user();
    if (!$user) {
        $next = (string)($_SERVER['REQUEST_URI'] ?? '');
        platform_redirect(platform_login_url_with_next($next));
    }

    if ($requiredRole !== null) {
        $actualRole = strtolower((string)($user['role'] ?? ''));
        $requiredRole = strtolower($requiredRole);
        if ($actualRole !== $requiredRole) {
            if ($actualRole === 'god') {
                return $user;
            }
            http_response_code(403);
            echo platform_h(platform_t('error_permission'));
            exit;
        }
    }
    return $user;
}

function platform_csrf_token(): string
{
    platform_start_session();
    if (!isset($_SESSION['platform_csrf']) || !is_string($_SESSION['platform_csrf']) || $_SESSION['platform_csrf'] === '') {
        $_SESSION['platform_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['platform_csrf'];
}

function platform_csrf_check(?string $token): bool
{
    platform_start_session();
    $sessionToken = $_SESSION['platform_csrf'] ?? '';
    if (!is_string($sessionToken) || $sessionToken === '') {
        return false;
    }
    if (!is_string($token) || $token === '') {
        return false;
    }
    return hash_equals($sessionToken, $token);
}

function platform_set_flash(string $type, string $message): void
{
    platform_start_session();
    $_SESSION['platform_flash'] = [
        'type' => $type === 'ok' ? 'ok' : 'err',
        'message' => $message,
    ];
}

function platform_consume_flash(): ?array
{
    platform_start_session();
    $flash = $_SESSION['platform_flash'] ?? null;
    unset($_SESSION['platform_flash']);
    return is_array($flash) ? $flash : null;
}

function platform_sanitize_next_path(string $next): string
{
    $next = trim($next);
    if ($next === '') {
        return '';
    }
    if (preg_match('/^https?:\/\//i', $next)) {
        return '';
    }
    if ($next[0] !== '/') {
        return '';
    }
    return $next;
}

function platform_slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    $value = trim($value, '-');
    if ($value === '') {
        $value = 'instance';
    }
    if (strlen($value) > 80) {
        $value = substr($value, 0, 80);
        $value = rtrim($value, '-');
    }
    return $value !== '' ? $value : 'instance';
}

function platform_instance_root_abs(): string
{
    $config = platform_load_config();
    $name = trim((string)($config['instance_root_dirname'] ?? 'instances'), '/');
    $path = platform_root_path() . '/' . ($name === '' ? 'instances' : $name);
    if (!is_dir($path)) {
        mkdir($path, 0775, true);
    }
    return $path;
}

function platform_template_paths(): array
{
    $config = platform_load_config();
    $paths = $config['template_paths'] ?? [];
    if (!is_array($paths) || count($paths) === 0) {
        return [];
    }
    $out = [];
    foreach ($paths as $p) {
        if (!is_string($p)) {
            continue;
        }
        $clean = trim($p, '/');
        if ($clean === '' || strpos($clean, '..') !== false) {
            continue;
        }
        $out[] = $clean;
    }
    return array_values(array_unique($out));
}

function platform_instance_template_dir_abs(): ?string
{
    $config = platform_load_config();
    $raw = trim((string)($config['instance_template_dir'] ?? ''), '/');
    if ($raw === '' || strpos($raw, '..') !== false) {
        return null;
    }
    $abs = platform_root_path() . '/' . $raw;
    if (!is_dir($abs)) {
        return null;
    }
    return $abs;
}

function platform_copy_recursive(string $src, string $dst): bool
{
    if (is_file($src)) {
        $dir = dirname($dst);
        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }
        return copy($src, $dst);
    }
    if (!is_dir($src)) {
        return false;
    }
    if (!is_dir($dst) && !mkdir($dst, 0775, true) && !is_dir($dst)) {
        return false;
    }
    $items = scandir($src);
    if (!is_array($items)) {
        return false;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $from = $src . '/' . $item;
        $to = $dst . '/' . $item;
        if (is_dir($from)) {
            if (!platform_copy_recursive($from, $to)) {
                return false;
            }
            continue;
        }
        if (!copy($from, $to)) {
            return false;
        }
    }
    return true;
}

function platform_remove_recursive(string $path): void
{
    if (!file_exists($path)) {
        return;
    }
    if (is_file($path) || is_link($path)) {
        @unlink($path);
        return;
    }
    $items = scandir($path);
    if (is_array($items)) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            platform_remove_recursive($path . '/' . $item);
        }
    }
    @rmdir($path);
}

function platform_instance_exists_by_slug(PDO $pdo, string $slug): bool
{
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM ar_instances WHERE slug = :slug");
    $stmt->execute([':slug' => $slug]);
    if (((int)$stmt->fetchColumn()) > 0) {
        return true;
    }
    $path = platform_instance_root_abs() . '/' . $slug;
    return file_exists($path);
}

function platform_resolve_unique_slug(PDO $pdo, string $baseSlug): string
{
    $baseSlug = platform_slugify($baseSlug);
    $candidate = $baseSlug;
    $i = 2;
    while (platform_instance_exists_by_slug($pdo, $candidate)) {
        $candidate = $baseSlug . '-' . $i;
        $i++;
        if ($i > 10000) {
            throw new RuntimeException('Could not generate a unique instance slug.');
        }
    }
    return $candidate;
}

function platform_write_json_file(string $path, array $payload): bool
{
    $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return false;
    }
    return file_put_contents($path, $json) !== false;
}

function platform_customize_instance_defaults(string $instanceDir, string $displayName, string $defaultLanguage): void
{
    $configJsonPath = $instanceDir . '/ar-card-config.json';
    if (is_file($configJsonPath)) {
        $raw = file_get_contents($configJsonPath);
        $config = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($config)) {
            if (!isset($config['content']) || !is_array($config['content'])) {
                $config['content'] = [];
            }
            foreach ($config['content'] as $langCode => $langData) {
                if (!is_array($langData)) {
                    continue;
                }
                $config['content'][$langCode]['title'] = $displayName;
            }
            platform_write_json_file($configJsonPath, $config);
            file_put_contents($instanceDir . '/ar-card-config.js', "window.AR_CARD_CONFIG = " . json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ";\n");
        }
    }

    $languagesJsonPath = $instanceDir . '/ar-card-languages.json';
    if (is_file($languagesJsonPath)) {
        $raw = file_get_contents($languagesJsonPath);
        $languages = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($languages)) {
            $languages['defaultLanguage'] = $defaultLanguage;
            platform_write_json_file($languagesJsonPath, $languages);
            file_put_contents($instanceDir . '/ar-card-languages.js', "window.AR_CARD_LANGUAGES = " . json_encode($languages, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ";\n");
        }
    }
}

function platform_create_instance(array $payload): array
{
    $displayName = trim((string)($payload['display_name'] ?? ''));
    $slugInput = trim((string)($payload['slug'] ?? ''));
    $username = trim((string)($payload['username'] ?? ''));
    $password = (string)($payload['password'] ?? '');
    $defaultLanguage = platform_normalize_panel_language((string)($payload['default_language'] ?? 'fa'));

    if ($displayName === '') {
        return [false, 'Workspace name is required.', null];
    }
    if (!platform_is_valid_username($username)) {
        return [false, platform_t('error_invalid_username'), null];
    }
    if (!platform_is_valid_password($password)) {
        return [false, platform_t('error_short_password'), null];
    }

    if (platform_find_user_by_username($username)) {
        return [false, platform_t('error_username_exists'), null];
    }

    $instanceLimit = platform_max_instances_per_god_user();
    if (platform_total_instances() >= $instanceLimit) {
        return [false, platform_t('error_instance_quota_reached', ['limit' => (string)$instanceLimit]), null];
    }

    $pdo = platform_db();
    $baseSlug = $slugInput !== '' ? platform_slugify($slugInput) : platform_slugify($displayName);
    $slug = platform_resolve_unique_slug($pdo, $baseSlug);
    $instanceRoot = platform_instance_root_abs();
    $instanceDir = $instanceRoot . '/' . $slug;
    if (file_exists($instanceDir)) {
        return [false, platform_t('error_slug_exists'), null];
    }

    if (!mkdir($instanceDir, 0775, true) && !is_dir($instanceDir)) {
        return [false, 'Could not create instance folder.', null];
    }

    $templateDir = platform_instance_template_dir_abs();
    if ($templateDir !== null) {
        $items = scandir($templateDir);
        if (!is_array($items)) {
            platform_remove_recursive($instanceDir);
            return [false, 'Cannot read instance template directory.', null];
        }
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $src = $templateDir . '/' . $item;
            $dst = $instanceDir . '/' . $item;
            if (!platform_copy_recursive($src, $dst)) {
                platform_remove_recursive($instanceDir);
                return [false, 'Failed copying template item: ' . $item, null];
            }
        }
    } else {
        $templatePaths = platform_template_paths();
        $sourceRoot = platform_root_path();
        foreach ($templatePaths as $relPath) {
            $src = $sourceRoot . '/' . $relPath;
            $dst = $instanceDir . '/' . $relPath;
            if (!file_exists($src)) {
                platform_remove_recursive($instanceDir);
                return [false, 'Template path is missing: ' . $relPath, null];
            }
            if (!platform_copy_recursive($src, $dst)) {
                platform_remove_recursive($instanceDir);
                return [false, 'Failed copying template path: ' . $relPath, null];
            }
        }
    }

    platform_customize_instance_defaults($instanceDir, $displayName, $defaultLanguage);

    $metadata = [
        'name' => $displayName,
        'slug' => $slug,
        'ownerUsername' => $username,
        'createdAt' => gmdate('c'),
    ];
    platform_write_json_file($instanceDir . '/instance-meta.json', $metadata);

    $relativeFolderPath = trim((string)(platform_load_config()['instance_root_dirname'] ?? 'instances'), '/') . '/' . $slug;
    try {
        $pdo->beginTransaction();
        $stmtInstance = $pdo->prepare(
            "INSERT INTO ar_instances (slug, display_name, folder_path, default_language)
             VALUES (:slug, :display_name, :folder_path, :default_language)"
        );
        $stmtInstance->execute([
            ':slug' => $slug,
            ':display_name' => $displayName,
            ':folder_path' => $relativeFolderPath,
            ':default_language' => $defaultLanguage,
        ]);
        $instanceId = (int)$pdo->lastInsertId();

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmtUser = $pdo->prepare(
            "INSERT INTO ar_users (username, password_hash, role, instance_id, is_active)
             VALUES (:username, :password_hash, 'client', :instance_id, 1)"
        );
        $stmtUser->execute([
            ':username' => $username,
            ':password_hash' => $hash,
            ':instance_id' => $instanceId,
        ]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        platform_remove_recursive($instanceDir);
        return [false, 'Database error while creating instance: ' . $e->getMessage(), null];
    }

    $row = [
        'slug' => $slug,
        'display_name' => $displayName,
        'folder_path' => $relativeFolderPath,
        'username' => $username,
    ];
    return [true, platform_t('success_instance_created'), $row];
}

function platform_total_instances(): int
{
    $pdo = platform_db();
    return (int)$pdo->query("SELECT COUNT(*) FROM ar_instances")->fetchColumn();
}

function platform_list_instances(): array
{
    $pdo = platform_db();
    $stmt = $pdo->query(
        "SELECT
            i.id,
            i.slug,
            i.display_name,
            i.folder_path,
            i.default_language,
            i.created_at,
            u.username AS owner_username
         FROM ar_instances i
         LEFT JOIN ar_users u
           ON u.instance_id = i.id
          AND u.role = 'client'
         ORDER BY i.id DESC"
    );
    $rows = $stmt->fetchAll();
    return is_array($rows) ? $rows : [];
}

function platform_find_instance_by_id(int $id): ?array
{
    $pdo = platform_db();
    $stmt = $pdo->prepare("SELECT * FROM ar_instances WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

function platform_detect_instance_slug_from_pathname(string $pathname): ?string
{
    $path = (string)(parse_url($pathname, PHP_URL_PATH) ?? $pathname);
    if ($path === '') {
        return null;
    }
    $instanceRoot = trim((string)(platform_load_config()['instance_root_dirname'] ?? 'instances'), '/');
    if ($instanceRoot === '') {
        $instanceRoot = 'instances';
    }
    if (!preg_match('#/' . preg_quote($instanceRoot, '#') . '/([a-z0-9-]+)/#i', $path, $m)) {
        return null;
    }
    $slug = strtolower(trim((string)($m[1] ?? '')));
    if (!preg_match('/^[a-z0-9-]{1,120}$/', $slug)) {
        return null;
    }
    return $slug;
}

function platform_allowed_analytics_events(): array
{
    return [
        'app_open',
        'target_found',
        'video_play',
        'video_unmute',
        'action_click',
        'language_toggle',
        'fullscreen',
    ];
}

function platform_record_analytics_event(string $instanceSlug, string $eventName, string $sessionKey = '', array $meta = [], string $userAgent = ''): bool
{
    $instanceSlug = strtolower(trim($instanceSlug));
    $eventName = strtolower(trim($eventName));
    if (!preg_match('/^[a-z0-9-]{1,120}$/', $instanceSlug)) {
        return false;
    }
    if (!in_array($eventName, platform_allowed_analytics_events(), true)) {
        return false;
    }

    $sessionKey = trim($sessionKey);
    if (strlen($sessionKey) > 128) {
        $sessionKey = substr($sessionKey, 0, 128);
    }
    $userAgent = trim($userAgent);
    if (strlen($userAgent) > 255) {
        $userAgent = substr($userAgent, 0, 255);
    }

    $metaJson = null;
    if (!empty($meta)) {
        $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($metaJson === false) {
            $metaJson = null;
        }
    }

    try {
        $pdo = platform_db();
        $stmt = $pdo->prepare(
            "INSERT INTO ar_instance_events (instance_slug, event_name, session_key, user_agent, meta_json)
             VALUES (:instance_slug, :event_name, :session_key, :user_agent, :meta_json)"
        );
        $stmt->execute([
            ':instance_slug' => $instanceSlug,
            ':event_name' => $eventName,
            ':session_key' => $sessionKey !== '' ? $sessionKey : null,
            ':user_agent' => $userAgent !== '' ? $userAgent : null,
            ':meta_json' => $metaJson,
        ]);
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

function platform_get_instance_analytics(string $instanceSlug, int $days = 14): array
{
    $instanceSlug = strtolower(trim($instanceSlug));
    if (!preg_match('/^[a-z0-9-]{1,120}$/', $instanceSlug)) {
        return [
            'days' => [],
            'totals' => [],
            'unique_sessions' => 0,
            'last_event_at' => null,
        ];
    }

    $days = max(1, min(60, $days));
    $fromDate = (new DateTimeImmutable('today'))->modify('-' . ($days - 1) . ' days')->format('Y-m-d');

    $result = [
        'days' => [],
        'totals' => [
            'app_open' => 0,
            'target_found' => 0,
            'video_play' => 0,
            'action_click' => 0,
            'video_unmute' => 0,
            'language_toggle' => 0,
            'fullscreen' => 0,
        ],
        'unique_sessions' => 0,
        'last_event_at' => null,
    ];

    for ($i = 0; $i < $days; $i++) {
        $day = (new DateTimeImmutable($fromDate))->modify("+{$i} days")->format('Y-m-d');
        $result['days'][$day] = [
            'day' => $day,
            'app_open' => 0,
            'target_found' => 0,
            'video_play' => 0,
            'action_click' => 0,
        ];
    }

    $pdo = platform_db();

    $stmtTotals = $pdo->prepare(
        "SELECT event_name, COUNT(*) AS c
         FROM ar_instance_events
         WHERE instance_slug = :slug
           AND DATE(event_ts) >= :from_date
         GROUP BY event_name"
    );
    $stmtTotals->execute([
        ':slug' => $instanceSlug,
        ':from_date' => $fromDate,
    ]);
    $rowsTotals = $stmtTotals->fetchAll();
    if (is_array($rowsTotals)) {
        foreach ($rowsTotals as $row) {
            $event = (string)($row['event_name'] ?? '');
            $count = (int)($row['c'] ?? 0);
            if (array_key_exists($event, $result['totals'])) {
                $result['totals'][$event] = $count;
            }
        }
    }

    $stmtUnique = $pdo->prepare(
        "SELECT COUNT(DISTINCT session_key) AS c
         FROM ar_instance_events
         WHERE instance_slug = :slug
           AND DATE(event_ts) >= :from_date
           AND session_key IS NOT NULL
           AND session_key <> ''"
    );
    $stmtUnique->execute([
        ':slug' => $instanceSlug,
        ':from_date' => $fromDate,
    ]);
    $result['unique_sessions'] = (int)$stmtUnique->fetchColumn();

    $stmtLast = $pdo->prepare(
        "SELECT MAX(event_ts) AS last_ts
         FROM ar_instance_events
         WHERE instance_slug = :slug"
    );
    $stmtLast->execute([':slug' => $instanceSlug]);
    $lastTs = $stmtLast->fetchColumn();
    $result['last_event_at'] = is_string($lastTs) && $lastTs !== '' ? $lastTs : null;

    $stmtDaily = $pdo->prepare(
        "SELECT DATE(event_ts) AS day, event_name, COUNT(*) AS c
         FROM ar_instance_events
         WHERE instance_slug = :slug
           AND DATE(event_ts) >= :from_date
         GROUP BY DATE(event_ts), event_name"
    );
    $stmtDaily->execute([
        ':slug' => $instanceSlug,
        ':from_date' => $fromDate,
    ]);
    $rowsDaily = $stmtDaily->fetchAll();
    if (is_array($rowsDaily)) {
        foreach ($rowsDaily as $row) {
            $day = (string)($row['day'] ?? '');
            $event = (string)($row['event_name'] ?? '');
            $count = (int)($row['c'] ?? 0);
            if (!isset($result['days'][$day])) {
                continue;
            }
            if (array_key_exists($event, $result['days'][$day])) {
                $result['days'][$day][$event] = $count;
            }
        }
    }

    $result['days'] = array_values($result['days']);
    return $result;
}

function platform_delete_instance(int $instanceId): array
{
    $instance = platform_find_instance_by_id($instanceId);
    if (!$instance) {
        return [false, platform_t('error_instance_not_found')];
    }

    $instanceRoot = realpath(platform_instance_root_abs());
    if ($instanceRoot === false) {
        return [false, 'Workspace root path is invalid.'];
    }

    $folderPathRel = trim((string)($instance['folder_path'] ?? ''), '/');
    $expectedRootPrefix = trim((string)(platform_load_config()['instance_root_dirname'] ?? 'instances'), '/');
    if ($folderPathRel === '' || strpos($folderPathRel, $expectedRootPrefix . '/') !== 0) {
        return [false, 'Workspace folder path is invalid.'];
    }

    $instanceDir = platform_root_path() . '/' . $folderPathRel;
    if (file_exists($instanceDir)) {
        $resolved = realpath($instanceDir);
        if ($resolved === false) {
            return [false, platform_t('error_instance_folder_delete_failed')];
        }
        if (strpos($resolved, $instanceRoot . DIRECTORY_SEPARATOR) !== 0) {
            return [false, platform_t('error_instance_folder_delete_failed')];
        }
        platform_remove_recursive($resolved);
        if (file_exists($resolved)) {
            return [false, platform_t('error_instance_folder_delete_failed')];
        }
    }

    $pdo = platform_db();
    try {
        $pdo->beginTransaction();
        $stmtDeleteEvents = $pdo->prepare("DELETE FROM ar_instance_events WHERE instance_slug = :slug");
        $stmtDeleteEvents->execute([':slug' => (string)($instance['slug'] ?? '')]);

        $stmtDeleteUsers = $pdo->prepare("DELETE FROM ar_users WHERE instance_id = :instance_id");
        $stmtDeleteUsers->execute([':instance_id' => $instanceId]);

        $stmtDeleteInstance = $pdo->prepare("DELETE FROM ar_instances WHERE id = :instance_id");
        $stmtDeleteInstance->execute([':instance_id' => $instanceId]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        return [false, 'Database error while deleting instance: ' . $e->getMessage()];
    }

    return [true, platform_t('success_instance_deleted')];
}

function platform_detect_instance_slug_from_admin_dir(string $adminDir): ?string
{
    $resolved = realpath($adminDir);
    if ($resolved === false) {
        $resolved = $adminDir;
    }
    $parts = preg_split('#[\\\\/]+#', $resolved);
    if (!is_array($parts)) {
        return null;
    }
    $instanceRoot = trim((string)(platform_load_config()['instance_root_dirname'] ?? 'instances'), '/');
    if ($instanceRoot === '') {
        $instanceRoot = 'instances';
    }
    $count = count($parts);
    for ($i = 0; $i < $count - 1; $i++) {
        if ($parts[$i] === $instanceRoot && isset($parts[$i + 1]) && $parts[$i + 1] !== '') {
            return $parts[$i + 1];
        }
    }
    return null;
}
