window.AR_CARD_CONFIG = {
    "theme": {
        "accentCyan": "#39d3ce",
        "panelBorderColor": "rgba(77, 232, 227, 0.36)",
        "panelBackgroundGradient": "linear-gradient(170deg, rgba(13, 19, 24, 0.94), rgba(7, 10, 14, 0.92))",
        "mainTextColor": "#f2f7fb"
    },
    "layout": {
        "targetTransformSmoothingFactor": 0.9,
        "panelBasePx": {
            "video": {
                "w": 320,
                "h": 180
            },
            "gallery": {
                "w": 320,
                "h": 180
            },
            "description": {
                "w": 320,
                "h": 122
            },
            "side": {
                "w": 170,
                "h": 312
            }
        },
        "panelGapPx": 10,
        "trackingRectUnits": {
            "width": 1,
            "height": 0.603528,
            "yOffset": 0,
            "zOffset": 0.01
        },
        "targetMask": {
            "enabled": true,
            "shape": "rounded",
            "cornerRadiusPx": 16,
            "image": "",
            "mode": "alpha",
            "autoUseUploadedTargetImage": true
        },
        "autoMatchTargetAspect": true,
        "frozenScreenPaddingPx": 20,
        "frozenScaleMin": 0.45,
        "frozenScaleMax": 2.2,
        "trackingSmoothingAlpha": 0.24
    },
    "ui": {
        "scanHintFontPx": 11,
        "scanHintPadding": "8px 12px",
        "startButtonFontPx": 13,
        "startButtonMinWidthPx": 172,
        "startButtonHeightPx": 40,
        "languageButtonFontPx": 12,
        "descriptionFontPx": 10.8,
        "descriptionLineHeight": 1.48,
        "descriptionPaddingPx": 10,
        "sidePanelPaddingPx": 10,
        "brandTitleFontPx": 15,
        "actionButtonFontPx": 10,
        "actionButtonMinHeightPx": 50,
        "actionButtonPadding": "5px 4px",
        "actionGridGapPx": 7,
        "actionIconSizePx": 16,
        "brandLogoSizePx": 46,
        "galleryDotSizePx": 6,
        "playButtonSizePx": 92,
        "playButtonFontPx": 11,
        "playIconSizePx": 34,
        "galleryIntervalMs": 2600,
        "galleryFadeMs": 90
    },
    "content": {
        "fa": {
            "scanHint": "",
            "startAr": "",
            "langBtn": "",
            "playCta": "",
            "title": "",
            "description": "",
            "logo": "",
            "gallery": [],
            "video": "",
            "actions": []
        },
        "en": {
            "scanHint": "",
            "startAr": "",
            "langBtn": "",
            "playCta": "",
            "title": "",
            "description": "",
            "logo": "",
            "gallery": [],
            "video": "",
            "actions": []
        }
    }
};
