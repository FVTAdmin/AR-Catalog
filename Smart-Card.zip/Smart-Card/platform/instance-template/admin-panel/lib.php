<?php
declare(strict_types=1);

function admin_project_root(): string
{
    $root = realpath(__DIR__ . '/..');
    return $root !== false ? $root : dirname(__DIR__);
}

function admin_find_platform_guard_path(): ?string
{
    $dir = admin_project_root();
    for ($i = 0; $i < 8; $i++) {
        $candidate = $dir . '/platform/guard.php';
        if (is_file($candidate)) {
            return $candidate;
        }
        $parent = dirname($dir);
        if ($parent === $dir) {
            break;
        }
        $dir = $parent;
    }
    return null;
}

function admin_require_platform_access_if_enabled(string $adminDir): void
{
    $guardPath = admin_find_platform_guard_path();
    if ($guardPath === null) {
        return;
    }
    require_once $guardPath;
    if (function_exists('platform_require_admin_panel_access')) {
        try {
            platform_require_admin_panel_access($adminDir);
        } catch (Throwable $e) {
            http_response_code(500);
            echo 'Access validation failed.';
            exit;
        }
    }
}

function admin_config_json_path(): string
{
    return admin_project_root() . '/ar-card-config.json';
}

function admin_config_js_path(): string
{
    return admin_project_root() . '/ar-card-config.js';
}

function admin_languages_json_path(): string
{
    return admin_project_root() . '/ar-card-languages.json';
}

function admin_languages_js_path(): string
{
    return admin_project_root() . '/ar-card-languages.js';
}

function admin_cache_version_json_path(): string
{
    return admin_project_root() . '/ar-cache-version.json';
}

function admin_settings_json_path(): string
{
    return __DIR__ . '/admin-settings.json';
}

function admin_upload_root(): string
{
    return admin_project_root() . '/assets/uploads/admin';
}

function admin_targets_path(): string
{
    $path = admin_project_root() . '/assets/mindar/targets.mind';
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    return $path;
}

function admin_default_settings(): array
{
    return [
        'target_compile_command_template' => '',
    ];
}

function admin_load_settings(): array
{
    $path = admin_settings_json_path();
    if (!file_exists($path)) {
        return admin_default_settings();
    }
    $json = file_get_contents($path);
    if ($json === false) {
        return admin_default_settings();
    }
    $data = json_decode($json, true);
    if (!is_array($data)) {
        return admin_default_settings();
    }
    return array_merge(admin_default_settings(), $data);
}

function admin_save_settings(array $settings): bool
{
    $payload = json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($payload === false) {
        return false;
    }
    return file_put_contents(admin_settings_json_path(), $payload) !== false;
}

function admin_load_config(): array
{
    $path = admin_config_json_path();
    if (!file_exists($path)) {
        return [];
    }
    $json = file_get_contents($path);
    if ($json === false) {
        return [];
    }
    $data = json_decode($json, true);
    return is_array($data) ? $data : [];
}

function admin_save_config(array $config): bool
{
    $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return false;
    }
    if (file_put_contents(admin_config_json_path(), $json) === false) {
        return false;
    }

    $js = "window.AR_CARD_CONFIG = " . $json . ";\n";
    return file_put_contents(admin_config_js_path(), $js) !== false;
}

function admin_default_language_registry(): array
{
    return [
        'defaultLanguage' => 'fa',
        'languages' => [
            [
                'code' => 'fa',
                'name' => 'Persian',
                'native' => 'فارسی',
                'direction' => 'rtl',
                'switchLabel' => 'EN',
            ],
            [
                'code' => 'en',
                'name' => 'English',
                'native' => 'English',
                'direction' => 'ltr',
                'switchLabel' => 'FA',
            ],
        ],
    ];
}

function admin_normalize_language_code($raw): string
{
    $code = strtolower(trim((string) $raw));
    $code = preg_replace('/[^a-z0-9_-]+/', '', $code) ?? '';
    if (strlen($code) > 24) {
        $code = substr($code, 0, 24);
    }
    return $code;
}

function admin_language_fallback_from_content(array $content): array
{
    $out = [];
    $seen = [];
    foreach ($content as $langCode => $_unused) {
        $code = admin_normalize_language_code($langCode);
        if ($code === '' || isset($seen[$code])) {
            continue;
        }
        $seen[$code] = true;
        $out[] = [
            'code' => $code,
            'name' => strtoupper($code),
            'native' => strtoupper($code),
            'direction' => 'ltr',
            'switchLabel' => strtoupper($code),
        ];
    }
    return $out;
}

function admin_normalize_language_registry(array $registry, array $contentFallback = []): array
{
    $rawLanguages = $registry['languages'] ?? [];
    if (!is_array($rawLanguages)) {
        $rawLanguages = [];
    }

    $languages = [];
    $seen = [];

    foreach ($rawLanguages as $lang) {
        if (!is_array($lang)) {
            continue;
        }

        $code = admin_normalize_language_code($lang['code'] ?? '');
        if ($code === '' || isset($seen[$code])) {
            continue;
        }
        $seen[$code] = true;

        $name = trim((string) ($lang['name'] ?? ''));
        if ($name === '') {
            $name = strtoupper($code);
        }

        $native = trim((string) ($lang['native'] ?? ''));
        if ($native === '') {
            $native = $name;
        }

        $direction = strtolower(trim((string) ($lang['direction'] ?? 'ltr')));
        if ($direction !== 'rtl') {
            $direction = 'ltr';
        }

        $switchLabel = trim((string) ($lang['switchLabel'] ?? ''));
        if ($switchLabel === '') {
            $switchLabel = strtoupper($code);
        }

        $languages[] = [
            'code' => $code,
            'name' => $name,
            'native' => $native,
            'direction' => $direction,
            'switchLabel' => $switchLabel,
        ];
    }

    if (count($languages) === 0) {
        $fromContent = admin_language_fallback_from_content($contentFallback);
        if (count($fromContent) > 0) {
            $languages = $fromContent;
        } else {
            $languages = admin_default_language_registry()['languages'];
        }
    }

    $defaultLanguage = admin_normalize_language_code($registry['defaultLanguage'] ?? '');
    $codes = array_map(static function ($l) {
        return (string) ($l['code'] ?? '');
    }, $languages);
    if ($defaultLanguage === '' || !in_array($defaultLanguage, $codes, true)) {
        $defaultLanguage = $codes[0];
    }

    return [
        'defaultLanguage' => $defaultLanguage,
        'languages' => array_values($languages),
    ];
}

function admin_load_language_registry(): array
{
    $path = admin_languages_json_path();
    $raw = null;
    if (file_exists($path)) {
        $json = file_get_contents($path);
        if ($json !== false) {
            $data = json_decode($json, true);
            if (is_array($data)) {
                $raw = $data;
            }
        }
    }

    if (!is_array($raw)) {
        $raw = admin_default_language_registry();
    }

    $config = admin_load_config();
    $content = [];
    if (isset($config['content']) && is_array($config['content'])) {
        $content = $config['content'];
    }

    return admin_normalize_language_registry($raw, $content);
}

function admin_save_language_registry(array $registry): bool
{
    $normalized = admin_normalize_language_registry($registry);
    $json = json_encode($normalized, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return false;
    }

    if (file_put_contents(admin_languages_json_path(), $json) === false) {
        return false;
    }

    $js = "window.AR_CARD_LANGUAGES = " . $json . ";\n";
    return file_put_contents(admin_languages_js_path(), $js) !== false;
}

function admin_bump_cache_version(): ?string
{
    $version = (string) ((int) round(microtime(true) * 1000));
    $payload = [
        'version' => $version,
        'updatedAt' => gmdate('c'),
    ];
    $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return null;
    }
    if (file_put_contents(admin_cache_version_json_path(), $json) === false) {
        return null;
    }
    return $version;
}

function admin_ensure_dir(string $dir): bool
{
    if (is_dir($dir)) {
        return true;
    }
    return mkdir($dir, 0775, true);
}

function admin_slug_file_name(string $name): string
{
    $name = strtolower($name);
    $name = preg_replace('/[^a-z0-9._-]+/', '-', $name) ?? 'file';
    $name = trim($name, '-');
    return $name !== '' ? $name : 'file';
}

function admin_uploaded_file(string $inputName): ?array
{
    if (!isset($_FILES[$inputName])) {
        return null;
    }
    $file = $_FILES[$inputName];
    if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    return $file;
}

function admin_upload_error_message(int $errCode, string $inputName): string
{
    if ($errCode === UPLOAD_ERR_INI_SIZE || $errCode === UPLOAD_ERR_FORM_SIZE) {
        $maxFile = (string)ini_get('upload_max_filesize');
        $maxPost = (string)ini_get('post_max_size');
        return "Upload failed for {$inputName}: file is too large (upload_max_filesize={$maxFile}, post_max_size={$maxPost}).";
    }
    if ($errCode === UPLOAD_ERR_PARTIAL) {
        return "Upload failed for {$inputName}: file was only partially uploaded.";
    }
    if ($errCode === UPLOAD_ERR_NO_TMP_DIR) {
        return "Upload failed for {$inputName}: missing temporary upload directory on server.";
    }
    if ($errCode === UPLOAD_ERR_CANT_WRITE) {
        return "Upload failed for {$inputName}: server could not write the uploaded file to disk.";
    }
    if ($errCode === UPLOAD_ERR_EXTENSION) {
        return "Upload failed for {$inputName}: blocked by a server extension.";
    }
    return "Upload failed for {$inputName} (error code {$errCode}).";
}

function admin_store_upload(string $inputName, array $allowedExtensions, string $subDir, string $prefix): array
{
    $file = admin_uploaded_file($inputName);
    if ($file === null) {
        return [null, null];
    }

    $errCode = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($errCode !== UPLOAD_ERR_OK) {
        return [null, admin_upload_error_message($errCode, $inputName)];
    }

    $tmpPath = (string) ($file['tmp_name'] ?? '');
    if ($tmpPath === '' || !is_uploaded_file($tmpPath)) {
        return [null, "Invalid upload source for {$inputName}."];
    }

    $originalName = (string) ($file['name'] ?? 'file');
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExtensions, true)) {
        $allowed = implode(', ', $allowedExtensions);
        return [null, "Invalid file type for {$inputName}. Allowed: {$allowed}."];
    }

    $targetDir = admin_upload_root() . '/' . trim($subDir, '/');
    if (!admin_ensure_dir($targetDir)) {
        return [null, "Cannot create upload directory: {$targetDir}"];
    }

    $base = admin_slug_file_name(pathinfo($originalName, PATHINFO_FILENAME));
    try {
        $rand = bin2hex(random_bytes(3));
    } catch (Throwable $e) {
        $rand = substr(md5((string) microtime(true)), 0, 6);
    }
    $fileName = admin_slug_file_name($prefix . '-' . $base . '-' . date('Ymd-His') . '-' . $rand) . '.' . $ext;
    $absolutePath = $targetDir . '/' . $fileName;
    if (!move_uploaded_file($tmpPath, $absolutePath)) {
        return [null, "Could not move uploaded file for {$inputName}."];
    }

    $relativePath = 'assets/uploads/admin/' . trim($subDir, '/') . '/' . $fileName;
    return [$relativePath, null];
}

function admin_try_compile_target(string $inputImageAbsolutePath): array
{
    if (!function_exists('exec')) {
        return [false, 'Server-side compile is not available (PHP exec() disabled).'];
    }

    $settings = admin_load_settings();
    $tpl = trim((string) ($settings['target_compile_command_template'] ?? ''));
    $outputPath = admin_targets_path();
    $inputArg = escapeshellarg($inputImageAbsolutePath);
    $outputArg = escapeshellarg($outputPath);
    $candidates = [];

    if ($tpl !== '') {
        $candidates[] = $tpl;
    }

    $candidates[] = 'mindar-image-target-compiler {input} {output}';
    $candidates[] = 'mindar-image-targets-compiler {input} {output}';
    $candidates[] = 'mindar-image-compiler {input} {output}';
    $candidates[] = 'mindar-compiler {input} {output}';

    $attemptErrors = [];
    foreach ($candidates as $candidateTpl) {
        $candidateTpl = trim($candidateTpl);
        if ($candidateTpl === '') {
            continue;
        }

        $cmd = str_replace(['{input}', '{output}'], [$inputArg, $outputArg], $candidateTpl);
        $lines = [];
        $code = 0;
        exec($cmd . ' 2>&1', $lines, $code);

        if ($code === 0 && file_exists($outputPath) && filesize($outputPath) > 0) {
            return [true, 'Target image compiled and the tracking file was updated on the server.'];
        }

        $tail = trim(implode("\n", array_slice($lines, -4)));
        $attemptErrors[] = $tail !== ''
            ? "{$candidateTpl} => {$tail}"
            : "{$candidateTpl} => exit code {$code}";
    }

    $suffix = '';
    if (!empty($attemptErrors)) {
        $suffix = "\nTried commands:\n- " . implode("\n- ", $attemptErrors);
    }
    return [false, 'Could not compile target image on server.' . $suffix];
}

function admin_save_compiled_mind_base64(string $base64Payload): array
{
    $clean = preg_replace('/\s+/', '', $base64Payload) ?? '';
    if ($clean === '') {
        return [false, 'Compiled target payload is empty.'];
    }

    $binary = base64_decode($clean, true);
    if ($binary === false || strlen($binary) === 0) {
        return [false, 'Compiled target payload is invalid.'];
    }

    $bytes = file_put_contents(admin_targets_path(), $binary);
    if ($bytes === false || $bytes <= 0) {
        return [false, 'Could not write the compiled tracking file.'];
    }

    return [true, 'Tracking file updated from the browser-generated target image.'];
}

function admin_post_string(array $source, string $key, string $fallback = ''): string
{
    $value = $source[$key] ?? $fallback;
    if (!is_string($value)) {
        return $fallback;
    }
    return trim($value);
}
