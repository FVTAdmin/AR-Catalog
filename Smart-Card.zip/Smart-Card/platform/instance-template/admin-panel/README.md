# AR Card Admin Panel

Open:

- `/admin-panel/index.php`

This panel can:

- Edit all texts for every language in the registry
- Manage language list dynamically (add/remove languages)
- Edit button labels and links
- Upload/replace video, logo, gallery images, button icons
- Configure target masking for video (`rect` / `rounded` / `circle`)
- Upload a mask image (PNG/SVG/WebP) for arbitrary target silhouettes
- Choose mask mode (`alpha` or `luminance`) for different mask file styles
- Auto-use uploaded target image as video mask to keep target shape and video shape aligned
- Auto-match target aspect ratio from uploaded target image
- Save to `ar-card-config.json` and regenerate `ar-card-config.js`
- Save language registry to `ar-card-languages.json` and regenerate `ar-card-languages.js`
- Upload `assets/mindar/targets.mind` directly
- One-click compile target image to `assets/mindar/targets.mind` directly in browser (no template needed)
- Auto-bump cache version so app refresh loads latest target/media/config
- Work with local MindAR compiler files in `assets/vendor` (no CDN dependency)
- Use multilingual panel UI (EN/FA/AR/ZH) via the panel language selector
- Respect central auth guard when `platform/` module is enabled
- Show local analytics (14-day KPI + chart) for instance panels, powered by local DB only

## Asset Layout

- `assets/media/*`: default video/image files used by AR card
- `assets/icons/*`: action button icons
- `assets/docs/*`: downloadable files (pdf/vcf/etc)
- `assets/loading/*`: loading overlay images
- `assets/mindar/targets.mind`: active AR target file
- `assets/uploads/admin/*`: files uploaded from admin panel
- `assets/vendor/*`: local A-Frame + MindAR runtime/compiler scripts

## Target Compile Flow

In the admin UI:

1. Pick `Upload target image (one-click compile)`
2. Click `Save All Changes`
3. The page compiles image to `.mind` in browser and uploads it as `assets/mindar/targets.mind`

Fallback options:

- Upload a `.mind` file directly (fastest/manual path)
- If browser compile fails, panel also tries server-side compile commands when available

No compile command template is required for normal use.

## Cache Busting

Every successful save in admin updates `ar-cache-version.json`.
The app checks this version on load and forces reload with `?v=...` when needed,
so updated `assets/mindar/targets.mind`, videos, gallery images, icons, and configs are fetched fresh.

## Access Control (when platform is enabled)

If `platform/guard.php` exists:

- Panel access requires login via `/platform/index.php`
- `god` can open all admin panels
- `client` can open only `/instances/<their-slug>/admin-panel/`
