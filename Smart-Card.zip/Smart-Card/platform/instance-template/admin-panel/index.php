<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
admin_require_platform_access_if_enabled(__DIR__);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$config = admin_load_config();
$languageRegistry = admin_load_language_registry();
$flash = $_SESSION['admin_flash'] ?? null;
unset($_SESSION['admin_flash']);

$languages = $languageRegistry['languages'] ?? [];
$defaultLanguage = (string) ($languageRegistry['defaultLanguage'] ?? ($languages[0]['code'] ?? ''));
$instanceAnalytics = null;
$instanceAnalyticsSlug = '';
$instanceAnalyticsError = '';
if (function_exists('platform_detect_instance_slug_from_admin_dir') && function_exists('platform_get_instance_analytics')) {
    try {
        $detectedSlug = platform_detect_instance_slug_from_admin_dir(__DIR__);
        if (is_string($detectedSlug) && $detectedSlug !== '') {
            $instanceAnalyticsSlug = $detectedSlug;
            $instanceAnalytics = platform_get_instance_analytics($detectedSlug, 14);
        }
    } catch (Throwable $e) {
        $instanceAnalyticsError = $e->getMessage();
    }
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function getv(array $arr, array $path, string $fallback = ''): string
{
    $value = $arr;
    foreach ($path as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) {
            return $fallback;
        }
        $value = $value[$segment];
    }
    return is_scalar($value) ? (string) $value : $fallback;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>AR Experience Manager</title>
  <style>
    :root {
      --bg: #0f141a;
      --panel: #151d25;
      --line: #283341;
      --text: #e9eef5;
      --muted: #9eb0c4;
      --accent: #39d3ce;
      --danger: #ff6b6b;
      --ok: #2ecc71;
    }
    * {
      box-sizing: border-box;
      -webkit-tap-highlight-color: transparent;
    }
    a,
    button,
    input,
    select,
    textarea {
      -webkit-tap-highlight-color: transparent;
      outline: none;
    }
    body {
      margin: 0;
      font-family: Tahoma, Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
    }
    .wrap {
      max-width: 1100px;
      margin: 0 auto;
      padding: 20px 14px 60px;
    }
    .top-tools {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      margin-bottom: 10px;
      gap: 8px;
      flex-wrap: wrap;
    }
    .panel-lang-tools {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      border: 1px solid #2c3e50;
      border-radius: 999px;
      padding: 5px 10px;
      background: #0e151d;
    }
    .panel-lang-tools label {
      color: var(--muted);
      font-size: 11px;
    }
    .panel-lang-tools select {
      min-width: 110px;
      width: auto;
      padding: 6px 8px;
      min-height: 30px;
      font-size: 11px;
      border-radius: 999px;
    }
    h1 {
      margin: 0 0 8px;
      font-size: 24px;
    }
    .muted {
      color: var(--muted);
      font-size: 13px;
      margin-bottom: 16px;
    }
    .flash {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 10px 12px;
      margin-bottom: 14px;
      font-size: 13px;
      background: #111821;
    }
    .flash.ok { border-color: rgba(46, 204, 113, 0.5); }
    .flash.err { border-color: rgba(255, 107, 107, 0.5); }

    .card {
      border: 1px solid var(--line);
      border-radius: 12px;
      background: var(--panel);
      padding: 14px;
      margin-bottom: 14px;
      overflow: hidden;
    }
    .card h2 {
      margin: 0 0 10px;
      font-size: 16px;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 10px;
    }
    .grid-3 {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 10px;
    }
    .field {
      display: flex;
      flex-direction: column;
      gap: 6px;
      min-width: 0;
    }
    label {
      color: #d6e2ee;
      font-size: 12px;
    }
    input[type="text"],
    input[type="number"],
    select,
    textarea {
      width: 100%;
      border: 1px solid #314153;
      background: #0e151d;
      color: #f0f5fb;
      border-radius: 8px;
      padding: 8px 9px;
      font-size: 12px;
    }
    textarea {
      min-height: 72px;
      resize: vertical;
      line-height: 1.4;
    }
    input[type="file"] {
      font-size: 12px;
      color: var(--muted);
      width: 100%;
      min-width: 0;
      display: block;
    }
    .admin-card-collapsible {
      display: grid;
      grid-template-rows: auto 0fr;
      transition: grid-template-rows 280ms ease;
    }
    .admin-card-collapsible.is-open {
      grid-template-rows: auto 1fr;
    }
    .card-collapse-toggle {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      width: 100%;
      background: transparent;
      color: inherit;
      border: 0;
      padding: 0;
      margin: 0;
      font-size: 16px;
      font-weight: 700;
      text-align: start;
      cursor: pointer;
      min-height: 26px;
    }
    .card-collapse-toggle.lang-title-toggle {
      color: var(--accent);
      font-size: 14px;
    }
    .card-collapse-toggle::after {
      content: "";
      width: 8px;
      height: 8px;
      border-right: 2px solid currentColor;
      border-bottom: 2px solid currentColor;
      transform: rotate(45deg);
      transition: transform 220ms ease;
      flex: 0 0 auto;
      margin-inline-start: 6px;
      opacity: 0.86;
    }
    .admin-card-collapsible.is-open > .card-collapse-toggle::after {
      transform: rotate(-135deg);
    }
    .card-collapse-body {
      min-height: 0;
      overflow: hidden;
      opacity: 0;
      transform: translateY(-4px);
      transition: opacity 180ms ease, transform 180ms ease, padding-top 180ms ease;
      padding-top: 0;
    }
    .admin-card-collapsible.is-open > .card-collapse-body {
      opacity: 1;
      transform: translateY(0);
      padding-top: 10px;
    }
    .divider {
      height: 1px;
      background: var(--line);
      margin: 14px 0;
    }
    .lang-title {
      margin: 0 0 10px;
      color: var(--accent);
      font-size: 14px;
      font-weight: 700;
    }
    .mini {
      font-size: 11px;
      color: var(--muted);
    }
    .compile-status {
      min-height: 18px;
      font-size: 12px;
      color: var(--accent);
      margin-top: 6px;
    }
    .languages-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .language-row {
      border: 1px solid #2e3c4d;
      border-radius: 9px;
      padding: 9px;
      display: grid;
      grid-template-columns: repeat(6, minmax(0, 1fr));
      gap: 8px;
      align-items: end;
    }
    .language-remove-btn,
    .language-add-btn {
      height: 34px;
      border: 1px solid #34506a;
      border-radius: 8px;
      background: #112131;
      color: #d8e9f8;
      font-size: 12px;
      cursor: pointer;
    }
    .language-add-btn {
      margin-top: 10px;
      width: 100%;
      border-color: rgba(57, 211, 206, 0.45);
      background: rgba(57, 211, 206, 0.12);
      color: #ccfffd;
      font-weight: 700;
    }
    .action-row {
      border: 1px solid #2e3c4d;
      border-radius: 9px;
      padding: 8px;
      margin-bottom: 8px;
    }
    .submit-row {
      position: sticky;
      bottom: 0;
      background: linear-gradient(to top, rgba(15, 20, 26, 0.95), rgba(15, 20, 26, 0));
      padding-top: 14px;
    }
    .submit-btn {
      width: 100%;
      border: 1px solid rgba(57, 211, 206, 0.6);
      border-radius: 10px;
      background: rgba(57, 211, 206, 0.15);
      color: #d9fffd;
      height: 44px;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
    }
    .submit-btn:hover {
      background: rgba(57, 211, 206, 0.22);
    }
    .analytics-grid {
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 1fr));
      gap: 8px;
      margin-top: 8px;
    }
    .analytics-kpi {
      border: 1px solid #2c3e50;
      border-radius: 9px;
      padding: 8px;
      background: #0f1822;
    }
    .analytics-kpi .k {
      color: #a8bdd2;
      font-size: 11px;
    }
    .analytics-kpi .v {
      font-size: 20px;
      font-weight: 700;
      line-height: 1.2;
      margin-top: 2px;
    }
    .analytics-chart {
      margin-top: 12px;
      border: 1px solid #2a3c4e;
      border-radius: 9px;
      padding: 10px 8px 6px;
      background: #0d141d;
    }
    .analytics-bars {
      height: 150px;
      display: grid;
      grid-template-columns: repeat(14, minmax(0, 1fr));
      gap: 4px;
      align-items: end;
    }
    .analytics-day {
      display: flex;
      align-items: end;
      justify-content: center;
      gap: 2px;
      height: 100%;
    }
    .analytics-bar {
      width: 8px;
      border-radius: 3px 3px 0 0;
      min-height: 2px;
      display: block;
    }
    .analytics-bar.open { background: #39d3ce; }
    .analytics-bar.play { background: #7fa8ff; }
    .analytics-bar.target { background: #f5a96a; }
    .analytics-labels {
      margin-top: 8px;
      display: grid;
      grid-template-columns: repeat(14, minmax(0, 1fr));
      gap: 4px;
    }
    .analytics-labels span {
      color: #96acc0;
      font-size: 9px;
      text-align: center;
      display: block;
    }
    .analytics-legend {
      margin-top: 8px;
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      color: #b3c7da;
      font-size: 11px;
    }
    .analytics-legend i {
      width: 10px;
      height: 10px;
      border-radius: 2px;
      display: inline-block;
      margin-right: 5px;
      vertical-align: -1px;
    }
    .analytics-last {
      margin-top: 8px;
      color: #9eb0c4;
      font-size: 11px;
    }
    @media (max-width: 860px) {
      .grid, .grid-3 { grid-template-columns: 1fr; }
      .language-row { grid-template-columns: 1fr; }
      .analytics-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
      .analytics-bars {
        height: 120px;
      }
      .panel-lang-tools {
        width: 100%;
        justify-content: space-between;
      }
      .panel-lang-tools select {
        flex: 1 1 auto;
      }
      .language-remove-btn,
      .language-add-btn,
      .submit-btn {
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="top-tools">
      <div class="panel-lang-tools">
        <label for="panel-lang-select">Panel Language</label>
        <select id="panel-lang-select">
          <option value="en">English</option>
          <option value="fa">فارسی</option>
          <option value="ar">العربية</option>
          <option value="zh">中文</option>
        </select>
      </div>
    </div>
    <h1>AR Experience Manager</h1>
    <div class="muted">Manage videos, gallery, brand media, text, and action buttons for the AR experience.</div>

    <?php if (is_array($flash)): ?>
      <div class="flash <?php echo !empty($flash['ok']) ? 'ok' : 'err'; ?>">
        <?php foreach (($flash['messages'] ?? []) as $msg): ?>
          <div><?php echo h((string)$msg); ?></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($instanceAnalyticsSlug !== ''): ?>
      <?php
        $totals = is_array($instanceAnalytics['totals'] ?? null) ? $instanceAnalytics['totals'] : [];
        $daysAnalytics = is_array($instanceAnalytics['days'] ?? null) ? $instanceAnalytics['days'] : [];
        $uniqueVisitors = (int)($instanceAnalytics['unique_sessions'] ?? 0);
        $lastEventAt = (string)($instanceAnalytics['last_event_at'] ?? '');

        $kpiAppOpen = (int)($totals['app_open'] ?? 0);
        $kpiTarget = (int)($totals['target_found'] ?? 0);
        $kpiVideoPlay = (int)($totals['video_play'] ?? 0);
        $kpiActionClick = (int)($totals['action_click'] ?? 0);

        $maxChartValue = 1;
        foreach ($daysAnalytics as $d) {
          $maxChartValue = max(
            $maxChartValue,
            (int)($d['app_open'] ?? 0),
            (int)($d['video_play'] ?? 0),
            (int)($d['target_found'] ?? 0)
          );
        }
      ?>
      <div class="card admin-card-collapsible">
        <h2>Local Analytics (14 days)</h2>
        <div class="mini">No external API. Data is stored locally in your host database.</div>
        <?php if ($instanceAnalyticsError !== ''): ?>
          <div class="flash err"><?php echo h($instanceAnalyticsError); ?></div>
        <?php else: ?>
          <div class="analytics-grid">
            <div class="analytics-kpi"><div class="k">App Opens</div><div class="v"><?php echo h((string)$kpiAppOpen); ?></div></div>
            <div class="analytics-kpi"><div class="k">Target Found</div><div class="v"><?php echo h((string)$kpiTarget); ?></div></div>
            <div class="analytics-kpi"><div class="k">Video Plays</div><div class="v"><?php echo h((string)$kpiVideoPlay); ?></div></div>
            <div class="analytics-kpi"><div class="k">Action Clicks</div><div class="v"><?php echo h((string)$kpiActionClick); ?></div></div>
            <div class="analytics-kpi"><div class="k">Unique Visitors</div><div class="v"><?php echo h((string)$uniqueVisitors); ?></div></div>
          </div>

          <div class="analytics-chart">
            <div class="analytics-bars">
              <?php foreach ($daysAnalytics as $d): ?>
                <?php
                  $open = (int)($d['app_open'] ?? 0);
                  $play = (int)($d['video_play'] ?? 0);
                  $target = (int)($d['target_found'] ?? 0);
                  $openH = max(2, (int)round(($open / $maxChartValue) * 100));
                  $playH = max(2, (int)round(($play / $maxChartValue) * 100));
                  $targetH = max(2, (int)round(($target / $maxChartValue) * 100));
                  $dayLabel = (string)($d['day'] ?? '');
                ?>
                <div class="analytics-day" title="<?php echo h($dayLabel . " | open:$open play:$play target:$target"); ?>">
                  <span class="analytics-bar open" style="height: <?php echo h((string)$openH); ?>%;"></span>
                  <span class="analytics-bar play" style="height: <?php echo h((string)$playH); ?>%;"></span>
                  <span class="analytics-bar target" style="height: <?php echo h((string)$targetH); ?>%;"></span>
                </div>
              <?php endforeach; ?>
            </div>
            <div class="analytics-labels">
              <?php foreach ($daysAnalytics as $d): ?>
                <?php
                  $dayLabel = (string)($d['day'] ?? '');
                  $label = strlen($dayLabel) >= 10 ? substr($dayLabel, 5, 5) : $dayLabel;
                ?>
                <span><?php echo h($label); ?></span>
              <?php endforeach; ?>
            </div>
            <div class="analytics-legend">
              <span><i style="background:#39d3ce;"></i>App Opens</span>
              <span><i style="background:#7fa8ff;"></i>Video Plays</span>
              <span><i style="background:#f5a96a;"></i>Target Found</span>
            </div>
          </div>
          <div class="analytics-last"><span>Last Event</span>: <?php echo h($lastEventAt !== '' ? $lastEventAt : '-'); ?></div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <form action="./save.php" method="post" enctype="multipart/form-data">
      <input type="hidden" name="compiled_mind_base64" value="" />
      <div class="card admin-card-collapsible">
        <h2>Layout & Typography (Global)</h2>
        <div class="grid-3">
          <div class="field">
            <label>Video Width (px)</label>
            <input type="number" name="config[layout][panelBasePx][video][w]" value="<?php echo h(getv($config, ['layout','panelBasePx','video','w'], '320')); ?>" />
          </div>
          <div class="field">
            <label>Video Height (px)</label>
            <input type="number" name="config[layout][panelBasePx][video][h]" value="<?php echo h(getv($config, ['layout','panelBasePx','video','h'], '180')); ?>" />
          </div>
          <div class="field">
            <label>Panel Gap (px)</label>
            <input type="number" name="config[layout][panelGapPx]" value="<?php echo h(getv($config, ['layout','panelGapPx'], '10')); ?>" />
          </div>
          <div class="field">
            <label>Gallery Width (px)</label>
            <input type="number" name="config[layout][panelBasePx][gallery][w]" value="<?php echo h(getv($config, ['layout','panelBasePx','gallery','w'], '320')); ?>" />
          </div>
          <div class="field">
            <label>Gallery Height (px)</label>
            <input type="number" name="config[layout][panelBasePx][gallery][h]" value="<?php echo h(getv($config, ['layout','panelBasePx','gallery','h'], '180')); ?>" />
          </div>
          <div class="field">
            <label>Description Height (px)</label>
            <input type="number" name="config[layout][panelBasePx][description][h]" value="<?php echo h(getv($config, ['layout','panelBasePx','description','h'], '122')); ?>" />
          </div>
          <div class="field">
            <label>Right Panel Width (px)</label>
            <input type="number" name="config[layout][panelBasePx][side][w]" value="<?php echo h(getv($config, ['layout','panelBasePx','side','w'], '170')); ?>" />
          </div>
          <div class="field">
            <label>Frozen Padding (px)</label>
            <input type="number" name="config[layout][frozenScreenPaddingPx]" value="<?php echo h(getv($config, ['layout','frozenScreenPaddingPx'], '20')); ?>" />
          </div>
          <div class="field">
            <label>Tracking Smooth (0-1)</label>
            <input type="text" name="config[layout][trackingSmoothingAlpha]" value="<?php echo h(getv($config, ['layout','trackingSmoothingAlpha'], '0.3')); ?>" />
          </div>
          <div class="field">
            <label>Target Rect Width (units)</label>
            <input type="text" name="config[layout][trackingRectUnits][width]" value="<?php echo h(getv($config, ['layout','trackingRectUnits','width'], '1')); ?>" />
          </div>
          <div class="field">
            <label>Target Rect Height (units)</label>
            <input type="text" name="config[layout][trackingRectUnits][height]" value="<?php echo h(getv($config, ['layout','trackingRectUnits','height'], '0.56')); ?>" />
          </div>
          <div class="field">
            <label>Auto Match Aspect From Target Image</label>
            <?php $autoMatchAspect = getv($config, ['layout','autoMatchTargetAspect'], '1'); ?>
            <select name="config[layout][autoMatchTargetAspect]">
              <option value="1" <?php echo ($autoMatchAspect === '1' || strtolower($autoMatchAspect) === 'true') ? 'selected' : ''; ?>>Enabled</option>
              <option value="0" <?php echo ($autoMatchAspect === '0' || strtolower($autoMatchAspect) === 'false') ? 'selected' : ''; ?>>Disabled</option>
            </select>
          </div>
          <div class="field">
            <label>Mask Target With Video</label>
            <?php $maskEnabled = getv($config, ['layout','targetMask','enabled'], '1'); ?>
            <select name="config[layout][targetMask][enabled]">
              <option value="1" <?php echo ($maskEnabled === '1' || strtolower($maskEnabled) === 'true') ? 'selected' : ''; ?>>Enabled</option>
              <option value="0" <?php echo ($maskEnabled === '0' || strtolower($maskEnabled) === 'false') ? 'selected' : ''; ?>>Disabled</option>
            </select>
          </div>
          <div class="field">
            <label>Target Mask Shape</label>
            <?php $maskShape = strtolower(getv($config, ['layout','targetMask','shape'], 'rounded')); ?>
            <select name="config[layout][targetMask][shape]">
              <option value="rect" <?php echo $maskShape === 'rect' ? 'selected' : ''; ?>>Rectangle</option>
              <option value="rounded" <?php echo $maskShape === 'rounded' ? 'selected' : ''; ?>>Rounded Rectangle</option>
              <option value="circle" <?php echo $maskShape === 'circle' ? 'selected' : ''; ?>>Circle</option>
            </select>
          </div>
          <div class="field">
            <label>Mask Corner Radius (px)</label>
            <input type="number" name="config[layout][targetMask][cornerRadiusPx]" value="<?php echo h(getv($config, ['layout','targetMask','cornerRadiusPx'], '16')); ?>" />
          </div>
          <div class="field">
            <label>Mask Image Path (PNG/SVG alpha)</label>
            <input type="text" name="config[layout][targetMask][image]" value="<?php echo h(getv($config, ['layout','targetMask','image'], '')); ?>" />
            <input type="file" name="upload_target_mask_image" accept=".png,.webp,.svg,image/png,image/webp,image/svg+xml" />
          </div>
          <div class="field">
            <label>Mask Image Mode</label>
            <?php $maskMode = strtolower(getv($config, ['layout','targetMask','mode'], 'alpha')); ?>
            <select name="config[layout][targetMask][mode]">
              <option value="alpha" <?php echo $maskMode === 'alpha' ? 'selected' : ''; ?>>Alpha (transparent areas)</option>
              <option value="luminance" <?php echo $maskMode === 'luminance' ? 'selected' : ''; ?>>Luminance (brightness)</option>
            </select>
          </div>
          <div class="field">
            <label>Auto Use Uploaded Target Image As Mask</label>
            <?php $autoUseTargetMask = getv($config, ['layout','targetMask','autoUseUploadedTargetImage'], '1'); ?>
            <select name="config[layout][targetMask][autoUseUploadedTargetImage]">
              <option value="1" <?php echo ($autoUseTargetMask === '1' || strtolower($autoUseTargetMask) === 'true') ? 'selected' : ''; ?>>Enabled</option>
              <option value="0" <?php echo ($autoUseTargetMask === '0' || strtolower($autoUseTargetMask) === 'false') ? 'selected' : ''; ?>>Disabled</option>
            </select>
          </div>
          <div class="field">
            <label>Description Font (px)</label>
            <input type="number" step="0.1" name="config[ui][descriptionFontPx]" value="<?php echo h(getv($config, ['ui','descriptionFontPx'], '10.8')); ?>" />
          </div>
          <div class="field">
            <label>Action Font (px)</label>
            <input type="number" step="0.1" name="config[ui][actionButtonFontPx]" value="<?php echo h(getv($config, ['ui','actionButtonFontPx'], '10')); ?>" />
          </div>
          <div class="field">
            <label>Brand Title Font (px)</label>
            <input type="number" step="0.1" name="config[ui][brandTitleFontPx]" value="<?php echo h(getv($config, ['ui','brandTitleFontPx'], '15')); ?>" />
          </div>
        </div>
      </div>

      <div class="card admin-card-collapsible">
        <h2>Languages</h2>
        <div class="mini">Add or remove app languages. The same list is saved in <code>ar-card-languages.json</code>.</div>
        <div class="languages-list" id="language-list">
          <?php foreach ($languages as $langIndex => $langDef): ?>
            <?php
              $langCode = (string)($langDef['code'] ?? '');
              $langName = (string)($langDef['name'] ?? '');
              $langNative = (string)($langDef['native'] ?? '');
              $langDirection = strtolower((string)($langDef['direction'] ?? 'ltr')) === 'rtl' ? 'rtl' : 'ltr';
              $langSwitchLabel = (string)($langDef['switchLabel'] ?? strtoupper($langCode));
            ?>
            <div class="language-row" data-language-row>
              <div class="field">
                <label>Code</label>
                <input type="text" value="<?php echo h($langCode); ?>" data-lang-field="code" name="language_registry[languages][<?php echo (int)$langIndex; ?>][code]" placeholder="fa / en / ar / de" />
              </div>
              <div class="field">
                <label>Name</label>
                <input type="text" value="<?php echo h($langName); ?>" data-lang-field="name" name="language_registry[languages][<?php echo (int)$langIndex; ?>][name]" placeholder="English" />
              </div>
              <div class="field">
                <label>Native</label>
                <input type="text" value="<?php echo h($langNative); ?>" data-lang-field="native" name="language_registry[languages][<?php echo (int)$langIndex; ?>][native]" placeholder="English / فارسی" />
              </div>
              <div class="field">
                <label>Direction</label>
                <select data-lang-field="direction" name="language_registry[languages][<?php echo (int)$langIndex; ?>][direction]">
                  <option value="ltr" <?php echo $langDirection === 'ltr' ? 'selected' : ''; ?>>LTR</option>
                  <option value="rtl" <?php echo $langDirection === 'rtl' ? 'selected' : ''; ?>>RTL</option>
                </select>
              </div>
              <div class="field">
                <label>Switch Label</label>
                <input type="text" value="<?php echo h($langSwitchLabel); ?>" data-lang-field="switchLabel" name="language_registry[languages][<?php echo (int)$langIndex; ?>][switchLabel]" placeholder="EN / FA" />
              </div>
              <div class="field">
                <label>Remove</label>
                <button type="button" class="language-remove-btn" data-language-remove>Remove</button>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="grid" style="margin-top: 10px;">
          <div class="field">
            <label>Default Language Code</label>
            <input type="text" name="language_registry[defaultLanguage]" value="<?php echo h($defaultLanguage); ?>" id="default-language-input" placeholder="fa" />
          </div>
        </div>
        <button type="button" class="language-add-btn" id="add-language-btn">+ Add Language</button>
        <template id="language-row-template">
          <div class="language-row" data-language-row>
            <div class="field">
              <label>Code</label>
              <input type="text" value="" data-lang-field="code" placeholder="fr" />
            </div>
            <div class="field">
              <label>Name</label>
              <input type="text" value="" data-lang-field="name" placeholder="French" />
            </div>
            <div class="field">
              <label>Native</label>
              <input type="text" value="" data-lang-field="native" placeholder="Français" />
            </div>
            <div class="field">
              <label>Direction</label>
              <select data-lang-field="direction">
                <option value="ltr" selected>LTR</option>
                <option value="rtl">RTL</option>
              </select>
            </div>
            <div class="field">
              <label>Switch Label</label>
              <input type="text" value="" data-lang-field="switchLabel" placeholder="FR" />
            </div>
            <div class="field">
              <label>Remove</label>
              <button type="button" class="language-remove-btn" data-language-remove>Remove</button>
            </div>
          </div>
        </template>
      </div>

      <div class="card admin-card-collapsible">
        <h2>Tracking File Update</h2>
        <div class="grid">
          <div class="field">
            <label>Upload compiled target file (.mind)</label>
            <input type="file" name="target_mind_file" accept=".mind" />
          </div>
          <div class="field">
            <label>Upload target image (one-click build)</label>
            <input type="file" name="target_image_file" accept="image/*" />
            <div class="mini">Choose an image and click Save. The panel will generate the tracking file automatically.</div>
            <div class="compile-status" id="browser-compile-status"></div>
          </div>
        </div>
      </div>

      <?php foreach ($languages as $langDef): ?>
        <?php
          $lang = (string)($langDef['code'] ?? '');
          if ($lang === '') continue;
          $langName = (string)($langDef['name'] ?? strtoupper($lang));
          $langNative = (string)($langDef['native'] ?? '');
          $title = $langName . ' (' . $lang . ')';
          if ($langNative !== '' && $langNative !== $langName) {
            $title .= ' - ' . $langNative;
          }
          $langContent = $config['content'][$lang] ?? [];
          $gallery = $langContent['gallery'] ?? [];
          $galleryCount = max(3, count($gallery));
          $actions = $langContent['actions'] ?? [];
          $actionCount = max(6, count($actions));
        ?>
        <div class="card admin-card-collapsible" data-language-content-card data-language-code="<?php echo h($lang); ?>">
          <h2 class="lang-title"><?php echo h($title); ?></h2>

          <div class="grid">
            <div class="field">
              <label>Scan Hint</label>
              <input type="text" name="config[content][<?php echo h($lang); ?>][scanHint]" value="<?php echo h(getv($config, ['content',$lang,'scanHint'])); ?>" />
            </div>
            <div class="field">
              <label>Start AR Text</label>
              <input type="text" name="config[content][<?php echo h($lang); ?>][startAr]" value="<?php echo h(getv($config, ['content',$lang,'startAr'])); ?>" />
            </div>
            <div class="field">
              <label>Language Toggle Label</label>
              <input type="text" name="config[content][<?php echo h($lang); ?>][langBtn]" value="<?php echo h(getv($config, ['content',$lang,'langBtn'])); ?>" />
            </div>
            <div class="field">
              <label>Play CTA</label>
              <input type="text" name="config[content][<?php echo h($lang); ?>][playCta]" value="<?php echo h(getv($config, ['content',$lang,'playCta'])); ?>" />
            </div>
            <div class="field">
              <label>Brand Title</label>
              <input type="text" name="config[content][<?php echo h($lang); ?>][title]" value="<?php echo h(getv($config, ['content',$lang,'title'])); ?>" />
            </div>
            <div class="field">
              <label>Video Path</label>
              <input type="text" name="config[content][<?php echo h($lang); ?>][video]" value="<?php echo h(getv($config, ['content',$lang,'video'])); ?>" />
              <input type="file" name="upload_<?php echo h($lang); ?>_video" accept="video/mp4,video/webm,video/quicktime" />
            </div>
            <div class="field">
              <label>Logo Path</label>
              <input type="text" name="config[content][<?php echo h($lang); ?>][logo]" value="<?php echo h(getv($config, ['content',$lang,'logo'])); ?>" />
              <input type="file" name="upload_<?php echo h($lang); ?>_logo" accept="image/*" />
            </div>
            <div class="field" style="grid-column: 1 / -1;">
              <label>Description</label>
              <textarea name="config[content][<?php echo h($lang); ?>][description]"><?php echo h(getv($config, ['content',$lang,'description'])); ?></textarea>
            </div>
          </div>

          <div class="divider"></div>
          <h2>Top Slideshow Images</h2>
          <div class="grid">
            <?php for ($i = 0; $i < $galleryCount; $i++): ?>
              <div class="field">
                <label>Gallery #<?php echo $i + 1; ?></label>
                <input type="text" name="config[content][<?php echo h($lang); ?>][gallery][<?php echo $i; ?>]" value="<?php echo h((string)($gallery[$i] ?? '')); ?>" />
                <input type="file" name="upload_<?php echo h($lang); ?>_gallery_<?php echo $i; ?>" accept="image/*" />
              </div>
            <?php endfor; ?>
          </div>

          <div class="divider"></div>
          <h2>Action Buttons</h2>
          <?php for ($i = 0; $i < $actionCount; $i++): ?>
            <?php $a = $actions[$i] ?? ['label' => '', 'href' => '', 'icon' => '']; ?>
            <div class="action-row">
              <div class="grid">
                <div class="field">
                  <label>Button Label #<?php echo $i + 1; ?></label>
                  <input type="text" name="config[content][<?php echo h($lang); ?>][actions][<?php echo $i; ?>][label]" value="<?php echo h((string)($a['label'] ?? '')); ?>" />
                </div>
                <div class="field">
                  <label>Button Link #<?php echo $i + 1; ?></label>
                  <input type="text" name="config[content][<?php echo h($lang); ?>][actions][<?php echo $i; ?>][href]" value="<?php echo h((string)($a['href'] ?? '')); ?>" />
                </div>
                <div class="field">
                  <label>Icon Path #<?php echo $i + 1; ?></label>
                  <input type="text" name="config[content][<?php echo h($lang); ?>][actions][<?php echo $i; ?>][icon]" value="<?php echo h((string)($a['icon'] ?? '')); ?>" />
                  <input type="file" name="upload_<?php echo h($lang); ?>_action_icon_<?php echo $i; ?>" accept="image/*" />
                </div>
              </div>
            </div>
          <?php endfor; ?>
        </div>
      <?php endforeach; ?>

      <div class="submit-row">
        <button class="submit-btn" type="submit">Save All Changes</button>
      </div>
    </form>
  </div>
  <script type="module">
    import { Compiler as MindARCompiler } from "../assets/vendor/mindar-image.prod.js";
    window.__MINDAR_COMPILER__ = MindARCompiler;
    window.dispatchEvent(new Event("mindar-compiler-ready"));
  </script>
  <script>
    (function () {
      const form = document.querySelector("form");
      if (!form) return;

      const languageList = document.getElementById("language-list");
      const addLanguageBtn = document.getElementById("add-language-btn");
      const languageTemplate = document.getElementById("language-row-template");
      const defaultLanguageInput = document.getElementById("default-language-input");

      const targetImageInput = form.querySelector('input[name="target_image_file"]');
      const targetMindInput = form.querySelector('input[name="target_mind_file"]');
      const compiledMindInput = form.querySelector('input[name="compiled_mind_base64"]');
      const submitBtn = form.querySelector(".submit-btn");
      const statusEl = document.getElementById("browser-compile-status");
      const canBrowserCompile = !!(targetImageInput && targetMindInput && compiledMindInput && submitBtn);

      let isCompiling = false;

      function normalizeCode(raw) {
        return String(raw || "").trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "").slice(0, 24);
      }

      function languageRows() {
        if (!languageList) return [];
        return Array.from(languageList.querySelectorAll("[data-language-row]"));
      }

      function activeLanguageCodes() {
        return languageRows().map(function (row) {
          const codeInput = row.querySelector('[data-lang-field="code"]');
          return normalizeCode(codeInput ? codeInput.value : "");
        }).filter(Boolean);
      }

      function assignLanguageNames() {
        const rows = languageRows();
        rows.forEach(function (row, index) {
          row.querySelectorAll("[data-lang-field]").forEach(function (input) {
            const field = input.getAttribute("data-lang-field");
            if (!field) return;
            input.setAttribute("name", "language_registry[languages][" + index + "][" + field + "]");
          });
        });
      }

      function ensureDefaultLanguageIsValid() {
        const rows = languageRows();
        rows.forEach(function (row) {
          const codeInput = row.querySelector('[data-lang-field="code"]');
          if (!codeInput) return;
          codeInput.value = normalizeCode(codeInput.value);
        });
        const codes = activeLanguageCodes();

        if (!codes.length) return;
        if (!defaultLanguageInput) return;

        defaultLanguageInput.value = normalizeCode(defaultLanguageInput.value);
        if (!codes.includes(defaultLanguageInput.value)) {
          defaultLanguageInput.value = codes[0];
        }
      }

      function syncLanguageContentCards() {
        const activeCodes = new Set(activeLanguageCodes());
        document.querySelectorAll("[data-language-content-card]").forEach(function (card) {
          const code = normalizeCode(card.getAttribute("data-language-code") || "");
          card.style.display = code !== "" && activeCodes.has(code) ? "" : "none";
        });
      }

      function setupCollapsibleCards() {
        const cards = Array.from(document.querySelectorAll(".admin-card-collapsible"));

        function findHeading(card) {
          for (let i = 0; i < card.children.length; i++) {
            const child = card.children[i];
            if (!child || !child.tagName) continue;
            if (child.tagName.toLowerCase() === "h2" || child.classList.contains("lang-title")) {
              return child;
            }
          }
          return null;
        }

        cards.forEach(function (card) {
          if (card.getAttribute("data-collapse-ready") === "1") return;

          const heading = findHeading(card);
          if (!heading) return;

          const title = (heading.textContent || "").replace(/\s+/g, " ").trim();
          const toggle = document.createElement("button");
          toggle.type = "button";
          toggle.className = "card-collapse-toggle";
          toggle.textContent = title;
          if (heading.classList.contains("lang-title")) {
            toggle.classList.add("lang-title-toggle");
          }

          const body = document.createElement("div");
          body.className = "card-collapse-body";
          let node = heading.nextSibling;
          while (node) {
            const next = node.nextSibling;
            body.appendChild(node);
            node = next;
          }

          heading.remove();
          card.insertBefore(toggle, card.firstChild);
          card.appendChild(body);
          card.classList.remove("is-open");
          card.setAttribute("data-collapse-ready", "1");

          toggle.addEventListener("click", function () {
            card.classList.toggle("is-open");
          });
        });
      }

      function removeLanguageRow(button) {
        const rows = languageRows();
        if (rows.length <= 1) {
          alert("At least one language is required.");
          return;
        }
        const row = button.closest("[data-language-row]");
        if (!row) return;
        row.remove();
        assignLanguageNames();
        ensureDefaultLanguageIsValid();
        syncLanguageContentCards();
      }

      if (languageList) {
        languageList.addEventListener("click", function (event) {
          const btn = event.target.closest("[data-language-remove]");
          if (!btn) return;
          removeLanguageRow(btn);
        });
        languageList.addEventListener("input", function (event) {
          const input = event.target.closest('[data-lang-field="code"]');
          if (input) {
            input.value = normalizeCode(input.value);
          }
          ensureDefaultLanguageIsValid();
          syncLanguageContentCards();
        });
      }

      if (addLanguageBtn && languageTemplate && languageList) {
        addLanguageBtn.addEventListener("click", function () {
          const frag = languageTemplate.content.cloneNode(true);
          languageList.appendChild(frag);
          assignLanguageNames();
          ensureDefaultLanguageIsValid();
          syncLanguageContentCards();
        });
      }

      if (defaultLanguageInput) {
        defaultLanguageInput.addEventListener("input", function () {
          defaultLanguageInput.value = normalizeCode(defaultLanguageInput.value);
        });
      }

      assignLanguageNames();
      ensureDefaultLanguageIsValid();
      setupCollapsibleCards();
      syncLanguageContentCards();

      function setStatus(text, isError) {
        if (!statusEl) return;
        statusEl.textContent = text || "";
        statusEl.style.color = isError ? "#ff8f8f" : "#39d3ce";
      }

      function waitForMindarCompiler(timeoutMs) {
        return new Promise(function (resolve, reject) {
          if (window.__MINDAR_COMPILER__) {
            resolve(window.__MINDAR_COMPILER__);
            return;
          }

          const timeout = setTimeout(function () {
            window.removeEventListener("mindar-compiler-ready", onReady);
            reject(new Error("Tracking compiler module did not load in time."));
          }, timeoutMs || 15000);

          function onReady() {
            clearTimeout(timeout);
            window.removeEventListener("mindar-compiler-ready", onReady);
            resolve(window.__MINDAR_COMPILER__);
          }

          window.addEventListener("mindar-compiler-ready", onReady);
        });
      }

      function fileToImage(file) {
        return new Promise(function (resolve, reject) {
          const objectUrl = URL.createObjectURL(file);
          const img = new Image();
          img.onload = function () {
            URL.revokeObjectURL(objectUrl);
            resolve(img);
          };
          img.onerror = function () {
            URL.revokeObjectURL(objectUrl);
            reject(new Error("Image could not be loaded for compile."));
          };
          img.src = objectUrl;
        });
      }

      function blobToBase64(blob) {
        return new Promise(function (resolve, reject) {
          const reader = new FileReader();
          reader.onload = function () {
            const result = String(reader.result || "");
            const comma = result.indexOf(",");
            resolve(comma >= 0 ? result.slice(comma + 1) : result);
          };
          reader.onerror = function () {
            reject(new Error("Could not encode compiled target."));
          };
          reader.readAsDataURL(blob);
        });
      }

      async function compileTargetInBrowser(file) {
        const CompilerClass = await waitForMindarCompiler(15000);
        if (!CompilerClass) throw new Error("Tracking compiler library failed to load.");
        const image = await fileToImage(file);
        const compiler = new CompilerClass();
        await compiler.compileImageTargets([image], function (progress) {
          const percent = Math.max(0, Math.min(100, Math.round(Number(progress || 0) * 100)));
          setStatus("Compiling target in browser... " + percent + "%", false);
        });
        const data = await compiler.exportData();
        const blob = new Blob([data], { type: "application/octet-stream" });
        return blobToBase64(blob);
      }

      form.addEventListener("submit", function (event) {
        assignLanguageNames();
        const rows = languageRows();
        if (rows.length === 0) {
          event.preventDefault();
          alert("At least one language is required.");
          return;
        }
        ensureDefaultLanguageIsValid();
        syncLanguageContentCards();

        if (!canBrowserCompile) {
          return;
        }

        if (isCompiling) {
          event.preventDefault();
          return;
        }

        const hasMindFile = targetMindInput.files && targetMindInput.files.length > 0;
        const imageFile = targetImageInput.files && targetImageInput.files.length > 0 ? targetImageInput.files[0] : null;

        if (hasMindFile || !imageFile) {
          compiledMindInput.value = "";
          return;
        }

        event.preventDefault();
        isCompiling = true;
        submitBtn.disabled = true;
        submitBtn.textContent = "Compiling...";
        setStatus("Preparing target image compile...", false);

        compileTargetInBrowser(imageFile)
          .then(function (base64Payload) {
            compiledMindInput.value = base64Payload;
            setStatus("Compile complete. Saving changes...", false);
            submitBtn.textContent = "Saving...";
            form.submit();
          })
          .catch(function (error) {
            const message = error && error.message ? error.message : "Unknown compile error.";
            setStatus("Browser compile failed: " + message + ". Trying server-side fallback...", true);
            compiledMindInput.value = "";
            submitBtn.textContent = "Saving...";
            form.submit();
          });
      });
    })();
  </script>
  <script>
    (function () {
      const panelLangSelect = document.getElementById("panel-lang-select");
      if (!panelLangSelect) return;

      const STORAGE_KEY = "ar_admin_panel_lang";
      const SUPPORTED = ["en", "fa", "ar", "zh"];

      const I18N = {
        fa: {
          "Panel Language": "زبان پنل",
          "AR Experience Manager": "مدیر تجربه AR",
          "Manage videos, gallery, brand media, text, and action buttons for the AR experience.": "ویدیو، گالری، رسانه‌های برند، متن‌ها و دکمه‌های عملیات تجربه AR را مدیریت کنید.",
          "Layout & Typography (Global)": "چیدمان و تایپوگرافی (عمومی)",
          "Video Width (px)": "عرض ویدیو (پیکسل)",
          "Video Height (px)": "ارتفاع ویدیو (پیکسل)",
          "Panel Gap (px)": "فاصله پنل‌ها (پیکسل)",
          "Gallery Width (px)": "عرض گالری (پیکسل)",
          "Gallery Height (px)": "ارتفاع گالری (پیکسل)",
          "Description Height (px)": "ارتفاع توضیحات (پیکسل)",
          "Right Panel Width (px)": "عرض پنل راست (پیکسل)",
          "Frozen Padding (px)": "پدینگ حالت ثابت (پیکسل)",
          "Tracking Smooth (0-1)": "نرمی رهگیری (0-1)",
          "Target Rect Width (units)": "عرض مستطیل تارگت (واحد)",
          "Target Rect Height (units)": "ارتفاع مستطیل تارگت (واحد)",
          "Auto Match Aspect From Target Image": "تطبیق خودکار نسبت تصویر تارگت",
          "Enabled": "فعال",
          "Disabled": "غیرفعال",
          "Mask Target With Video": "ماسک تارگت با ویدیو",
          "Target Mask Shape": "شکل ماسک تارگت",
          "Rectangle": "مستطیل",
          "Rounded Rectangle": "مستطیل گرد",
          "Circle": "دایره",
          "Mask Corner Radius (px)": "شعاع گوشه ماسک (پیکسل)",
          "Mask Image Path (PNG/SVG alpha)": "مسیر تصویر ماسک (PNG/SVG آلفا)",
          "Mask Image Mode": "حالت تصویر ماسک",
          "Alpha (transparent areas)": "آلفا (ناحیه‌های شفاف)",
          "Luminance (brightness)": "روشنایی (Luminance)",
          "Auto Use Uploaded Target Image As Mask": "استفاده خودکار از تصویر تارگت آپلود شده به‌عنوان ماسک",
          "Description Font (px)": "فونت توضیحات (پیکسل)",
          "Action Font (px)": "فونت دکمه‌ها (پیکسل)",
          "Brand Title Font (px)": "فونت عنوان برند (پیکسل)",
          "Languages": "زبان‌ها",
          "Add or remove app languages. The same list is saved in ar-card-languages.json.": "زبان‌های اپ را اضافه یا حذف کنید. همین لیست در ar-card-languages.json ذخیره می‌شود.",
          "Code": "کد",
          "Name": "نام",
          "Native": "نام بومی",
          "Direction": "جهت",
          "Switch Label": "برچسب سوییچ",
          "Remove": "حذف",
          "Default Language Code": "کد زبان پیش‌فرض",
          "+ Add Language": "+ افزودن زبان",
          "Tracking File Update": "به‌روزرسانی فایل رهگیری",
          "Upload compiled target file (.mind)": "آپلود فایل رهگیریِ کامپایل‌شده (.mind)",
          "Upload target image (one-click build)": "آپلود تصویر تارگت (ساخت تک‌کلیکی)",
          "Choose an image and click Save. The panel will generate the tracking file automatically.": "یک تصویر انتخاب کنید و ذخیره بزنید. پنل فایل رهگیری را به‌صورت خودکار تولید می‌کند.",
          "Description": "توضیحات",
          "Top Slideshow Images": "تصاویر اسلایدشوی بالا",
          "Main Video": "ویدیوی اصلی",
          "Brand Logo": "لوگوی برند",
          "Action Buttons": "دکمه‌های عملیات",
          "Scan Hint": "متن راهنمای اسکن",
          "Start AR Text": "متن شروع AR",
          "Language Toggle Label": "برچسب تغییر زبان",
          "Play CTA": "متن دکمه پخش",
          "Brand Title": "عنوان برند",
          "Media": "رسانه",
          "Content Texts": "متن‌های محتوا",
          "Save All Changes": "ذخیره همه تغییرات",
          "Top Slideshow Image Path #": "مسیر تصویر اسلاید #",
          "Action #": "اکشن #",
          "Button Label #": "متن دکمه #",
          "Button Link #": "لینک دکمه #",
          "Icon Path #": "مسیر آیکن #",
          "Local Analytics (14 days)": "تحلیل محلی (۱۴ روز اخیر)",
          "No external API. Data is stored locally in your host database.": "بدون API خارجی. داده‌ها به‌صورت محلی در دیتابیس هاست شما ذخیره می‌شوند.",
          "App Opens": "تعداد باز شدن اپ",
          "Target Found": "تعداد تشخیص تارگت",
          "Video Plays": "تعداد پخش ویدیو",
          "Action Clicks": "تعداد کلیک دکمه‌ها",
          "Unique Visitors": "بازدیدکننده یکتا",
          "Last Event": "آخرین رویداد",
          "Instance": "نمونه"
        },
        ar: {
          "Panel Language": "لغة اللوحة",
          "AR Experience Manager": "مدير تجربة AR",
          "Manage videos, gallery, brand media, text, and action buttons for the AR experience.": "أدر الفيديو والمعرض ووسائط العلامة والنصوص وأزرار الإجراءات لتجربة AR.",
          "Layout & Typography (Global)": "التخطيط والطباعة (عام)",
          "Video Width (px)": "عرض الفيديو (بكسل)",
          "Video Height (px)": "ارتفاع الفيديو (بكسل)",
          "Panel Gap (px)": "المسافة بين اللوحات (بكسل)",
          "Gallery Width (px)": "عرض المعرض (بكسل)",
          "Gallery Height (px)": "ارتفاع المعرض (بكسل)",
          "Description Height (px)": "ارتفاع الوصف (بكسل)",
          "Right Panel Width (px)": "عرض اللوحة اليمنى (بكسل)",
          "Frozen Padding (px)": "حشوة وضع التثبيت (بكسل)",
          "Tracking Smooth (0-1)": "تنعيم التتبع (0-1)",
          "Target Rect Width (units)": "عرض مستطيل الهدف (وحدة)",
          "Target Rect Height (units)": "ارتفاع مستطيل الهدف (وحدة)",
          "Auto Match Aspect From Target Image": "مطابقة الأبعاد تلقائيًا من صورة الهدف",
          "Enabled": "مفعل",
          "Disabled": "معطل",
          "Mask Target With Video": "قناع الهدف بالفيديو",
          "Target Mask Shape": "شكل قناع الهدف",
          "Rectangle": "مستطيل",
          "Rounded Rectangle": "مستطيل بحواف دائرية",
          "Circle": "دائرة",
          "Mask Corner Radius (px)": "نصف قطر الزاوية (بكسل)",
          "Mask Image Path (PNG/SVG alpha)": "مسار صورة القناع (PNG/SVG alpha)",
          "Mask Image Mode": "وضع صورة القناع",
          "Alpha (transparent areas)": "ألفا (المناطق الشفافة)",
          "Luminance (brightness)": "السطوع (Luminance)",
          "Auto Use Uploaded Target Image As Mask": "استخدام صورة الهدف المرفوعة تلقائيًا كقناع",
          "Description Font (px)": "خط الوصف (بكسل)",
          "Action Font (px)": "خط الأزرار (بكسل)",
          "Brand Title Font (px)": "خط عنوان العلامة (بكسل)",
          "Languages": "اللغات",
          "Add or remove app languages. The same list is saved in ar-card-languages.json.": "أضف أو احذف لغات التطبيق. يتم حفظ نفس القائمة في ar-card-languages.json.",
          "Code": "الرمز",
          "Name": "الاسم",
          "Native": "الاسم الأصلي",
          "Direction": "الاتجاه",
          "Switch Label": "نص التبديل",
          "Remove": "حذف",
          "Default Language Code": "رمز اللغة الافتراضية",
          "+ Add Language": "+ إضافة لغة",
          "Tracking File Update": "تحديث ملف التتبع",
          "Upload compiled target file (.mind)": "رفع ملف التتبع المجمّع (.mind)",
          "Upload target image (one-click build)": "رفع صورة الهدف (إنشاء بنقرة واحدة)",
          "Choose an image and click Save. The panel will generate the tracking file automatically.": "اختر صورة ثم اضغط حفظ. ستنشئ اللوحة ملف التتبع تلقائيًا.",
          "Description": "الوصف",
          "Top Slideshow Images": "صور العرض العلوي",
          "Main Video": "الفيديو الرئيسي",
          "Brand Logo": "شعار العلامة",
          "Action Buttons": "أزرار الإجراءات",
          "Scan Hint": "نص تلميح المسح",
          "Start AR Text": "نص بدء AR",
          "Language Toggle Label": "نص تبديل اللغة",
          "Play CTA": "نص زر التشغيل",
          "Brand Title": "عنوان العلامة",
          "Media": "الوسائط",
          "Content Texts": "نصوص المحتوى",
          "Save All Changes": "حفظ كل التغييرات",
          "Top Slideshow Image Path #": "مسار صورة العرض #",
          "Action #": "إجراء #",
          "Button Label #": "عنوان الزر #",
          "Button Link #": "رابط الزر #",
          "Icon Path #": "مسار الأيقونة #",
          "Local Analytics (14 days)": "تحليلات محلية (آخر 14 يومًا)",
          "No external API. Data is stored locally in your host database.": "بدون API خارجي. يتم حفظ البيانات محليًا في قاعدة بيانات الاستضافة.",
          "App Opens": "مرات فتح التطبيق",
          "Target Found": "مرات اكتشاف الهدف",
          "Video Plays": "مرات تشغيل الفيديو",
          "Action Clicks": "نقرات الإجراءات",
          "Unique Visitors": "زوار فريدون",
          "Last Event": "آخر حدث",
          "Instance": "النسخة"
        },
        zh: {
          "Panel Language": "面板语言",
          "AR Experience Manager": "AR 体验管理器",
          "Manage videos, gallery, brand media, text, and action buttons for the AR experience.": "管理 AR 体验的视频、图库、品牌媒体、文本和操作按钮。",
          "Layout & Typography (Global)": "布局与排版（全局）",
          "Video Width (px)": "视频宽度（像素）",
          "Video Height (px)": "视频高度（像素）",
          "Panel Gap (px)": "面板间距（像素）",
          "Gallery Width (px)": "图库宽度（像素）",
          "Gallery Height (px)": "图库高度（像素）",
          "Description Height (px)": "描述高度（像素）",
          "Right Panel Width (px)": "右侧面板宽度（像素）",
          "Frozen Padding (px)": "固定模式内边距（像素）",
          "Tracking Smooth (0-1)": "跟踪平滑度（0-1）",
          "Target Rect Width (units)": "目标矩形宽度（单位）",
          "Target Rect Height (units)": "目标矩形高度（单位）",
          "Auto Match Aspect From Target Image": "根据目标图自动匹配比例",
          "Enabled": "启用",
          "Disabled": "禁用",
          "Mask Target With Video": "用视频遮罩目标",
          "Target Mask Shape": "目标遮罩形状",
          "Rectangle": "矩形",
          "Rounded Rectangle": "圆角矩形",
          "Circle": "圆形",
          "Mask Corner Radius (px)": "遮罩圆角半径（像素）",
          "Mask Image Path (PNG/SVG alpha)": "遮罩图路径（PNG/SVG alpha）",
          "Mask Image Mode": "遮罩图模式",
          "Alpha (transparent areas)": "Alpha（透明区域）",
          "Luminance (brightness)": "亮度（Luminance）",
          "Auto Use Uploaded Target Image As Mask": "自动将上传目标图作为遮罩",
          "Description Font (px)": "描述字体（像素）",
          "Action Font (px)": "按钮字体（像素）",
          "Brand Title Font (px)": "品牌标题字体（像素）",
          "Languages": "语言",
          "Add or remove app languages. The same list is saved in ar-card-languages.json.": "添加或删除应用语言。相同列表会保存到 ar-card-languages.json。",
          "Code": "代码",
          "Name": "名称",
          "Native": "本地名",
          "Direction": "方向",
          "Switch Label": "切换标签",
          "Remove": "删除",
          "Default Language Code": "默认语言代码",
          "+ Add Language": "+ 添加语言",
          "Tracking File Update": "跟踪文件更新",
          "Upload compiled target file (.mind)": "上传已编译的跟踪文件 (.mind)",
          "Upload target image (one-click build)": "上传目标图片（一键生成）",
          "Choose an image and click Save. The panel will generate the tracking file automatically.": "选择图片后点击保存，面板会自动生成跟踪文件。",
          "Description": "描述",
          "Top Slideshow Images": "顶部轮播图",
          "Main Video": "主视频",
          "Brand Logo": "品牌 Logo",
          "Action Buttons": "操作按钮",
          "Scan Hint": "扫描提示",
          "Start AR Text": "启动 AR 文案",
          "Language Toggle Label": "语言切换标签",
          "Play CTA": "播放按钮文案",
          "Brand Title": "品牌标题",
          "Media": "媒体",
          "Content Texts": "内容文本",
          "Save All Changes": "保存所有更改",
          "Top Slideshow Image Path #": "轮播图路径 #",
          "Action #": "动作 #",
          "Button Label #": "按钮文案 #",
          "Button Link #": "按钮链接 #",
          "Icon Path #": "图标路径 #",
          "Local Analytics (14 days)": "本地分析（最近14天）",
          "No external API. Data is stored locally in your host database.": "不使用外部 API。数据保存在你的主机本地数据库中。",
          "App Opens": "应用打开次数",
          "Target Found": "目标识别次数",
          "Video Plays": "视频播放次数",
          "Action Clicks": "动作点击次数",
          "Unique Visitors": "独立访客",
          "Last Event": "最后事件",
          "Instance": "实例"
        }
      };

      function normalizeLang(value) {
        const v = String(value || "").trim().toLowerCase();
        return SUPPORTED.includes(v) ? v : "en";
      }

      function translateDynamic(base, map) {
        if (map[base]) return map[base];

        let m = base.match(/^Top Slideshow Image Path #(\d+)$/);
        if (m) return (map["Top Slideshow Image Path #"] || "Top Slideshow Image #") + m[1];
        m = base.match(/^Action #(\d+)$/);
        if (m) return (map["Action #"] || "Action #") + m[1];
        m = base.match(/^Button Label #(\d+)$/);
        if (m) return (map["Button Label #"] || "Button Label #") + m[1];
        m = base.match(/^Button Link #(\d+)$/);
        if (m) return (map["Button Link #"] || "Button Link #") + m[1];
        m = base.match(/^Icon Path #(\d+)$/);
        if (m) return (map["Icon Path #"] || "Icon Path #") + m[1];
        return base;
      }

      function applyLanguage(lang) {
        const nextLang = normalizeLang(lang);
        localStorage.setItem(STORAGE_KEY, nextLang);
        panelLangSelect.value = nextLang;
        const isRtl = nextLang === "fa" || nextLang === "ar";
        document.documentElement.lang = nextLang;
        document.documentElement.dir = isRtl ? "rtl" : "ltr";

        const map = I18N[nextLang] || {};
        const targets = document.querySelectorAll("h1,h2,label,button,.muted,.mini,option,.analytics-kpi .k,.analytics-legend span,.analytics-last span");
        targets.forEach(function (el) {
          if (el.closest("script,style")) return;
          const raw = (el.textContent || "").replace(/\s+/g, " ").trim();
          if (!raw) return;
          if (!el.dataset.i18nBase) {
            el.dataset.i18nBase = raw;
          }
          const base = el.dataset.i18nBase;
          if (nextLang === "en") {
            el.textContent = base;
            return;
          }
          el.textContent = translateDynamic(base, map);
        });
      }

      panelLangSelect.addEventListener("change", function () {
        applyLanguage(panelLangSelect.value);
      });

      const qsLang = new URL(window.location.href).searchParams.get("panelLang");
      const savedLang = localStorage.getItem(STORAGE_KEY);
      applyLanguage(qsLang || savedLang || "en");
    })();
  </script>
</body>
</html>
