<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
admin_require_platform_access_if_enabled(__DIR__);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Location: ./index.php');
    exit;
}

$messages = [];
$errors = [];
$targetUpdated = false;

$config = admin_load_config();
$settings = admin_load_settings();

if (!isset($config['content']) || !is_array($config['content'])) {
    $config['content'] = [];
}
if (!isset($config['layout']) || !is_array($config['layout'])) {
    $config['layout'] = [];
}
if (!isset($config['ui']) || !is_array($config['ui'])) {
    $config['ui'] = [];
}

$postedConfig = $_POST['config'] ?? [];
if (!is_array($postedConfig)) {
    $postedConfig = [];
}

$postedSettings = $_POST['settings'] ?? [];
if (!is_array($postedSettings)) {
    $postedSettings = [];
}

function to_int($v, int $fallback, int $min = 1, int $max = 5000): int
{
    if (!is_numeric($v)) return $fallback;
    $n = (int) $v;
    return max($min, min($max, $n));
}

function to_float($v, float $fallback, float $min, float $max): float
{
    if (!is_numeric($v)) return $fallback;
    $n = (float) $v;
    return max($min, min($max, $n));
}

function to_text($v, string $fallback = ''): string
{
    if (!is_string($v)) return $fallback;
    return trim($v);
}

function to_bool_flag($v, bool $fallback = false): bool
{
    if (is_bool($v)) return $v;
    if (is_int($v) || is_float($v)) return ((int)$v) !== 0;
    if (!is_string($v)) return $fallback;
    $value = strtolower(trim($v));
    if (in_array($value, ['1', 'true', 'yes', 'on'], true)) return true;
    if (in_array($value, ['0', 'false', 'no', 'off', ''], true)) return false;
    return $fallback;
}

// Layout updates
$layoutIn = $postedConfig['layout'] ?? [];
$base = $layoutIn['panelBasePx'] ?? [];

$config['layout']['panelBasePx']['video']['w'] = to_int($base['video']['w'] ?? ($config['layout']['panelBasePx']['video']['w'] ?? 320), (int)($config['layout']['panelBasePx']['video']['w'] ?? 320), 120, 1200);
$config['layout']['panelBasePx']['video']['h'] = to_int($base['video']['h'] ?? ($config['layout']['panelBasePx']['video']['h'] ?? 180), (int)($config['layout']['panelBasePx']['video']['h'] ?? 180), 80, 900);
$config['layout']['panelBasePx']['gallery']['w'] = to_int($base['gallery']['w'] ?? ($config['layout']['panelBasePx']['gallery']['w'] ?? 320), (int)($config['layout']['panelBasePx']['gallery']['w'] ?? 320), 120, 1200);
$config['layout']['panelBasePx']['gallery']['h'] = to_int($base['gallery']['h'] ?? ($config['layout']['panelBasePx']['gallery']['h'] ?? 180), (int)($config['layout']['panelBasePx']['gallery']['h'] ?? 180), 60, 900);
$config['layout']['panelBasePx']['description']['h'] = to_int($base['description']['h'] ?? ($config['layout']['panelBasePx']['description']['h'] ?? 122), (int)($config['layout']['panelBasePx']['description']['h'] ?? 122), 50, 900);
$config['layout']['panelBasePx']['side']['w'] = to_int($base['side']['w'] ?? ($config['layout']['panelBasePx']['side']['w'] ?? 170), (int)($config['layout']['panelBasePx']['side']['w'] ?? 170), 80, 900);

$config['layout']['panelGapPx'] = to_int($layoutIn['panelGapPx'] ?? ($config['layout']['panelGapPx'] ?? 10), (int)($config['layout']['panelGapPx'] ?? 10), 0, 120);
$config['layout']['frozenScreenPaddingPx'] = to_int($layoutIn['frozenScreenPaddingPx'] ?? ($config['layout']['frozenScreenPaddingPx'] ?? 20), (int)($config['layout']['frozenScreenPaddingPx'] ?? 20), 0, 120);
$config['layout']['trackingSmoothingAlpha'] = to_float($layoutIn['trackingSmoothingAlpha'] ?? ($config['layout']['trackingSmoothingAlpha'] ?? 0.3), (float)($config['layout']['trackingSmoothingAlpha'] ?? 0.3), 0.01, 1.0);

$trackingRectIn = $layoutIn['trackingRectUnits'] ?? [];
if (!isset($config['layout']['trackingRectUnits']) || !is_array($config['layout']['trackingRectUnits'])) {
    $config['layout']['trackingRectUnits'] = [];
}
$config['layout']['trackingRectUnits']['width'] = to_float(
    $trackingRectIn['width'] ?? ($config['layout']['trackingRectUnits']['width'] ?? 1.0),
    (float)($config['layout']['trackingRectUnits']['width'] ?? 1.0),
    0.2,
    3.0
);
$config['layout']['trackingRectUnits']['height'] = to_float(
    $trackingRectIn['height'] ?? ($config['layout']['trackingRectUnits']['height'] ?? 0.56),
    (float)($config['layout']['trackingRectUnits']['height'] ?? 0.56),
    0.2,
    3.0
);

$targetMaskIn = $layoutIn['targetMask'] ?? [];
if (!is_array($targetMaskIn)) {
    $targetMaskIn = [];
}
$existingTargetMask = $config['layout']['targetMask'] ?? [];
if (!is_array($existingTargetMask)) {
    $existingTargetMask = [];
}
$targetMaskEnabled = to_bool_flag(
    $targetMaskIn['enabled'] ?? ($existingTargetMask['enabled'] ?? true),
    true
);
$targetMaskShape = strtolower(to_text(
    $targetMaskIn['shape'] ?? ($existingTargetMask['shape'] ?? 'rounded'),
    'rounded'
));
if (!in_array($targetMaskShape, ['rect', 'rounded', 'circle'], true)) {
    $targetMaskShape = 'rounded';
}
$targetMaskCornerRadiusPx = to_int(
    $targetMaskIn['cornerRadiusPx'] ?? ($existingTargetMask['cornerRadiusPx'] ?? 16),
    (int)($existingTargetMask['cornerRadiusPx'] ?? 16),
    0,
    240
);
$targetMaskImagePath = to_text(
    $targetMaskIn['image'] ?? ($existingTargetMask['image'] ?? ''),
    ''
);
$targetMaskMode = strtolower(to_text(
    $targetMaskIn['mode'] ?? ($existingTargetMask['mode'] ?? 'alpha'),
    'alpha'
));
if (!in_array($targetMaskMode, ['alpha', 'luminance'], true)) {
    $targetMaskMode = 'alpha';
}
$targetMaskAutoUseUploadedTargetImage = to_bool_flag(
    $targetMaskIn['autoUseUploadedTargetImage'] ?? ($existingTargetMask['autoUseUploadedTargetImage'] ?? true),
    true
);
$config['layout']['targetMask'] = [
    'enabled' => $targetMaskEnabled,
    'shape' => $targetMaskShape,
    'cornerRadiusPx' => $targetMaskCornerRadiusPx,
    'image' => $targetMaskImagePath,
    'mode' => $targetMaskMode,
    'autoUseUploadedTargetImage' => $targetMaskAutoUseUploadedTargetImage,
];

$config['layout']['autoMatchTargetAspect'] = to_bool_flag(
    $layoutIn['autoMatchTargetAspect'] ?? ($config['layout']['autoMatchTargetAspect'] ?? true),
    true
);

// UI updates
$uiIn = $postedConfig['ui'] ?? [];
$uiNumericFields = [
    'descriptionFontPx' => [6, 48],
    'actionButtonFontPx' => [6, 48],
    'brandTitleFontPx' => [6, 64],
];
foreach ($uiNumericFields as $key => [$min, $max]) {
    $fallback = (float)($config['ui'][$key] ?? 10);
    $config['ui'][$key] = to_float($uiIn[$key] ?? $fallback, $fallback, $min, $max);
}

$settings['target_compile_command_template'] = to_text($postedSettings['target_compile_command_template'] ?? ($settings['target_compile_command_template'] ?? ''));
if (!admin_save_settings($settings)) {
    $errors[] = 'Could not save admin settings.';
}

$languageRegistryIn = $_POST['language_registry'] ?? [];
if (!is_array($languageRegistryIn)) {
    $languageRegistryIn = [];
}
$languageRegistry = admin_normalize_language_registry($languageRegistryIn, $config['content']);
if (!admin_save_language_registry($languageRegistry)) {
    $errors[] = 'Could not save language registry files.';
} else {
    $messages[] = 'Language registry saved.';
}

$languages = array_map(static function ($langDef) {
    return (string) ($langDef['code'] ?? '');
}, $languageRegistry['languages']);

$existingContent = $config['content'];
$nextContent = [];

foreach ($languages as $lang) {
    $langCurrent = [];
    if (isset($existingContent[$lang]) && is_array($existingContent[$lang])) {
        $langCurrent = $existingContent[$lang];
    }
    if (!isset($langCurrent['gallery']) || !is_array($langCurrent['gallery'])) {
        $langCurrent['gallery'] = [];
    }
    if (!isset($langCurrent['actions']) || !is_array($langCurrent['actions'])) {
        $langCurrent['actions'] = [];
    }

    $langIn = $postedConfig['content'][$lang] ?? [];
    if (!is_array($langIn)) {
        $langIn = [];
    }

    $textFields = ['scanHint', 'startAr', 'langBtn', 'playCta', 'title', 'description', 'logo', 'video'];
    foreach ($textFields as $field) {
        $langCurrent[$field] = to_text($langIn[$field] ?? ($langCurrent[$field] ?? ''));
    }

    $galleryIn = $langIn['gallery'] ?? [];
    if (!is_array($galleryIn)) {
        $galleryIn = [];
    }
    $gallery = [];
    foreach ($galleryIn as $item) {
        $path = to_text($item);
        if ($path !== '') {
            $gallery[] = $path;
        }
    }
    if (!empty($gallery)) {
        $langCurrent['gallery'] = array_values($gallery);
    }

    $actionsIn = $langIn['actions'] ?? [];
    if (!is_array($actionsIn)) {
        $actionsIn = [];
    }
    $actions = [];
    foreach ($actionsIn as $a) {
        if (!is_array($a)) {
            continue;
        }
        $label = to_text($a['label'] ?? '');
        $href = to_text($a['href'] ?? '');
        $icon = to_text($a['icon'] ?? '');
        if ($label === '' && $href === '' && $icon === '') {
            continue;
        }
        $actions[] = ['label' => $label, 'href' => $href, 'icon' => $icon];
    }
    if (!empty($actions)) {
        $langCurrent['actions'] = $actions;
    }

    // Uploads: video + logo
    [$videoPath, $videoErr] = admin_store_upload("upload_{$lang}_video", ['mp4', 'webm', 'mov', 'm4v'], 'videos', "{$lang}-video");
    if ($videoErr) {
        $errors[] = $videoErr;
    }
    if ($videoPath) {
        $langCurrent['video'] = $videoPath;
        $messages[] = strtoupper($lang) . " video uploaded.";
    }

    [$logoPath, $logoErr] = admin_store_upload("upload_{$lang}_logo", ['png', 'jpg', 'jpeg', 'webp', 'gif'], 'images', "{$lang}-logo");
    if ($logoErr) {
        $errors[] = $logoErr;
    }
    if ($logoPath) {
        $langCurrent['logo'] = $logoPath;
        $messages[] = strtoupper($lang) . " logo uploaded.";
    }

    // Uploads: gallery
    $galleryCount = max(3, count($langCurrent['gallery'] ?? []));
    for ($i = 0; $i < $galleryCount; $i++) {
        [$imgPath, $imgErr] = admin_store_upload("upload_{$lang}_gallery_{$i}", ['png', 'jpg', 'jpeg', 'webp', 'gif'], 'images', "{$lang}-gallery-{$i}");
        if ($imgErr) {
            $errors[] = $imgErr;
        }
        if ($imgPath) {
            if (!isset($langCurrent['gallery']) || !is_array($langCurrent['gallery'])) {
                $langCurrent['gallery'] = [];
            }
            $langCurrent['gallery'][$i] = $imgPath;
            $messages[] = strtoupper($lang) . " gallery #" . ($i + 1) . " uploaded.";
        }
    }
    if (isset($langCurrent['gallery']) && is_array($langCurrent['gallery'])) {
        $langCurrent['gallery'] = array_values(array_filter($langCurrent['gallery'], static function ($v) {
            return is_string($v) && trim($v) !== '';
        }));
    }

    // Uploads: action icons
    $actionCount = max(6, count($langCurrent['actions'] ?? []));
    for ($i = 0; $i < $actionCount; $i++) {
        [$iconPath, $iconErr] = admin_store_upload("upload_{$lang}_action_icon_{$i}", ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg'], 'icons', "{$lang}-action-{$i}");
        if ($iconErr) {
            $errors[] = $iconErr;
        }
        if ($iconPath) {
            if (!isset($langCurrent['actions'][$i])) {
                $langCurrent['actions'][$i] = ['label' => '', 'href' => '#', 'icon' => $iconPath];
            } else {
                $langCurrent['actions'][$i]['icon'] = $iconPath;
            }
            $messages[] = strtoupper($lang) . " action icon #" . ($i + 1) . " uploaded.";
        }
    }

    $nextContent[$lang] = $langCurrent;
}

$config['content'] = $nextContent;

// Direct .mind upload (recommended)
$mindFile = admin_uploaded_file('target_mind_file');
if ($mindFile !== null) {
    $mindErrCode = (int) ($mindFile['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($mindErrCode === UPLOAD_ERR_OK) {
        $name = (string) ($mindFile['name'] ?? '');
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($ext !== 'mind') {
            $errors[] = 'Target file must be .mind';
        } else {
            $tmp = (string) ($mindFile['tmp_name'] ?? '');
            if ($tmp === '' || !is_uploaded_file($tmp)) {
                $errors[] = 'Invalid .mind upload.';
            } elseif (!move_uploaded_file($tmp, admin_targets_path())) {
                $errors[] = 'Could not replace the compiled tracking file with the uploaded .mind file.';
            } else {
                $messages[] = 'Compiled tracking file updated from uploaded .mind file.';
                $targetUpdated = true;
            }
        }
    } elseif ($mindErrCode !== UPLOAD_ERR_NO_FILE) {
        $errors[] = "target_mind_file upload error code {$mindErrCode}.";
    }
}

$compiledMindBase64 = to_text($_POST['compiled_mind_base64'] ?? '');
if (!$targetUpdated && $compiledMindBase64 !== '') {
    [$okCompiled, $compiledMessage] = admin_save_compiled_mind_base64($compiledMindBase64);
    if ($okCompiled) {
        $messages[] = $compiledMessage;
        $targetUpdated = true;
    } else {
        $errors[] = $compiledMessage;
    }
}

// Optional: compile from uploaded target image
$targetImageAbsolutePath = null;
[$targetImageRel, $targetImageErr] = admin_store_upload('target_image_file', ['png', 'jpg', 'jpeg', 'webp'], 'targets-source', 'target');
if ($targetImageErr) $errors[] = $targetImageErr;
if ($targetImageRel) {
    $targetImageAbsolutePath = admin_project_root() . '/' . $targetImageRel;
    $messages[] = 'Target image uploaded.';

    $autoMatchTargetAspect = to_bool_flag($config['layout']['autoMatchTargetAspect'] ?? true, true);
    if ($autoMatchTargetAspect) {
        $imgSize = @getimagesize($targetImageAbsolutePath);
        $imgWidth = (int)($imgSize[0] ?? 0);
        $imgHeight = (int)($imgSize[1] ?? 0);
        if ($imgWidth > 0 && $imgHeight > 0) {
            $targetRatio = max(0.2, min(3.0, $imgHeight / $imgWidth));
            if (!isset($config['layout']['trackingRectUnits']) || !is_array($config['layout']['trackingRectUnits'])) {
                $config['layout']['trackingRectUnits'] = [];
            }
            $config['layout']['trackingRectUnits']['width'] = 1.0;
            $config['layout']['trackingRectUnits']['height'] = round($targetRatio, 6);
            $messages[] = 'Tracking aspect auto-matched to target image (' . round($targetRatio, 4) . ').';
        }
    }
}

if (!$targetUpdated && $targetImageAbsolutePath !== null) {
    [$ok, $compileMessage] = admin_try_compile_target($targetImageAbsolutePath);
    if ($ok) {
        $messages[] = $compileMessage;
        $targetUpdated = true;
    } else {
        $errors[] = $compileMessage;
    }
}

[$targetMaskImageUploadedPath, $targetMaskImageUploadErr] = admin_store_upload(
    'upload_target_mask_image',
    ['png', 'webp', 'svg'],
    'masks',
    'target-mask'
);
if ($targetMaskImageUploadErr) {
    $errors[] = $targetMaskImageUploadErr;
}
if ($targetMaskImageUploadedPath) {
    if (!isset($config['layout']) || !is_array($config['layout'])) {
        $config['layout'] = [];
    }
    if (!isset($config['layout']['targetMask']) || !is_array($config['layout']['targetMask'])) {
        $config['layout']['targetMask'] = [];
    }
    $config['layout']['targetMask']['image'] = $targetMaskImageUploadedPath;
    $messages[] = 'Target mask image uploaded.';
}

if (!$targetMaskImageUploadedPath && $targetImageRel && $targetMaskAutoUseUploadedTargetImage) {
    if (!isset($config['layout']) || !is_array($config['layout'])) {
        $config['layout'] = [];
    }
    if (!isset($config['layout']['targetMask']) || !is_array($config['layout']['targetMask'])) {
        $config['layout']['targetMask'] = [];
    }
    $config['layout']['targetMask']['image'] = $targetImageRel;
    $messages[] = 'Target mask image auto-updated from uploaded target image.';
}

if (!admin_save_config($config)) {
    $errors[] = 'Failed to save ar-card-config.json or ar-card-config.js';
} else {
    $messages[] = 'Config saved.';
    $newCacheVersion = admin_bump_cache_version();
    if ($newCacheVersion === null) {
        $errors[] = 'Config saved but failed to update cache version.';
    } else {
        $messages[] = "Cache version bumped: {$newCacheVersion}";
    }
}

$_SESSION['admin_flash'] = [
    'ok' => empty($errors),
    'messages' => array_merge($messages, $errors),
];

header('Location: ./index.php');
exit;
