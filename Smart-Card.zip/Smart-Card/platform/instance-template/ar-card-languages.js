window.AR_CARD_LANGUAGES = {
    "defaultLanguage": "fa",
    "languages": [
        {
            "code": "fa",
            "name": "Persian",
            "native": "فارسی",
            "direction": "rtl",
            "switchLabel": "EN"
        },
        {
            "code": "en",
            "name": "English",
            "native": "English",
            "direction": "ltr",
            "switchLabel": "FA"
        }
    ]
};
